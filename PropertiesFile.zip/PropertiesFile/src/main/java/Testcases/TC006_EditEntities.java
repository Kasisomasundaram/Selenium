package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC006_EditEntities extends ProjectSpecificMethods {
	
	@Test
	public void editEntities() throws InterruptedException {
		
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickLegalEntities()
		.searchLegalEntities()
		.clickEditLegalEntities()
		.editCompanyNameinLegalEntities()
		.editDescriptioninLegalEntities()
		.editStatusinLegalEntities()
		.editSaveinLegalEntities();		
	}

}
