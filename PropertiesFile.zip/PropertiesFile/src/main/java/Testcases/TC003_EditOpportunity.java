package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC003_EditOpportunity extends ProjectSpecificMethods {
	
	@Test
	public void editOpportunity() throws InterruptedException {
		
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickSales()
		.clickOpportunity()
		.searchOpportunity()
		.clickEditButton()
		.editCloseDate()
		.editStage()
		.editDeliveryStatus()
		.editDescription()
		.editSave()
		.stageText();
	}

}
