package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC008_CreateWorkTypeGroup extends ProjectSpecificMethods {
	
	@Test
	public void createWorkTypeGroup() throws InterruptedException {
		
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickWorkTypeGroup()
		.clickWorkTypeGroupsTab()
		.clickNewWorkTypeGroup()
		.enterWorkName()
		.clicksave()
		.verifyText();
	}

}
