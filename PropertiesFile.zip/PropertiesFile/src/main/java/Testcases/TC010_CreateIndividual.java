package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC010_CreateIndividual extends ProjectSpecificMethods {
	
	@Test
	public void createWorkTypeGroup() throws InterruptedException {
		
		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickIndividuals()
		.clickIndividualTab()
		.clickNewIndividual()
		.enterLastName()
		.clickSave();
	}

}
