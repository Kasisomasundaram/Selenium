package Testcases;

import org.testng.annotations.Test;

import Base.ProjectSpecificMethods;
import Pages.LoginPage;

public class TC007_Dashboard_Assignment extends ProjectSpecificMethods{


	@Test
	public void dashboard() throws InterruptedException {

		new LoginPage()
		.enterUserName()
		.enterPassword()
		.clickLogIn()
		.clickAppLauncher()
		.clickViewAll()
		.clickServiceConsole()
		.clickDashBoardfromDropDown()
		.clickNewDashboard()
		.enterNameinDashboard()
		.enterDescriptioninDashboard()
		.verifyTitle()
		.clickDone()
		.verifyDashboardName()
		.clickSubscribe()
		.clickDaily()
		.chooseTime()
		.clickSubscribeSave()
		.verifyDashboardSubscription()
		.closeWorkOutTab()
		.clickPrivateDashBoards()
		.searchDashboardName()
		.clickDropDownitem()
		.clickDelete()
		.confirmDelete()
		.itemNotAvailable();
	}

}
