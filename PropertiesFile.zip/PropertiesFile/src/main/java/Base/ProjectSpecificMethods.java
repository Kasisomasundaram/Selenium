package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import io.github.bonigarcia.wdm.WebDriverManager;
import utils.DataLibrary;

public class ProjectSpecificMethods extends DataLibrary{

	public static ChromeDriver driver;
	public static String excelFileName;
	public static Properties prop;

	@BeforeMethod
	public void launchApplication() throws IOException {
		
		FileInputStream fis = new FileInputStream("./src/main/resources/Dashboard.properties");
		prop = new Properties();
		prop.load(fis);

		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(options);

		//Launch the SalesForce URL
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();
	}

	@DataProvider(name = "fetchData")
	public Object[][] fetchData() throws IOException {
		return utils.DataLibrary.readExcelData(excelFileName);
	}	

}

