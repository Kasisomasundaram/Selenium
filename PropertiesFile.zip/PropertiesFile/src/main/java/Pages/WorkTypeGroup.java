package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Base.ProjectSpecificMethods;

public class WorkTypeGroup extends ProjectSpecificMethods{


	//Click on the Dropdown icon in the Work Type Groups tab
	public WorkTypeGroup clickWorkTypeGroupsTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.clickWorkTypeGroupsTab.xpath"))));
		Thread.sleep(5000);
		return this;
	}
	//Click on New Work Type Group
	public WorkTypeGroup clickNewWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.clickNewWorkTypeGroup.xpath"))));
		Thread.sleep(3000);
		return this;
	}

	//Enter Work Type Group Name as 'Salesforce Automation by Your Name'
	public WorkTypeGroup enterWorkName() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.enterWorkName.xpath"))).sendKeys("Salesforce Automation by Sivaraj");
		Thread.sleep(5000);
		return this;
	}

	//click Save
	public WorkTypeGroup clicksave() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.clicksaveWTG.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//verify Work Type Group Name
	public WorkTypeGroup verifyText() {
		String verifyText = driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.verifyText.xpath"))).getText();
		System.out.println(verifyText);
		return this;
	}

	//Search the Work Type Group 'Salesforce Automation by Your Name'
	public WorkTypeGroup searchWorkTypeGroupText() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.searchWorkTypeGroupText.xpath"))).sendKeys("Salesforce Automation by Sivaraj"+Keys.ENTER);
		Thread.sleep(4000);
		return this;
	}

	//Click on the Dropdown icon and Select Edit
	public WorkTypeGroup selectEditDropDown() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.selectEditDropDown.xpath"))));
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.selectEditDropEdit.xpath"))));
		Thread.sleep(3000);
		return this;
	}

	//Enter Description as 'Automation'.
	public WorkTypeGroup editDescription() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.editDescriptionClear.xpath"))).clear();
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.editDescription.xpath"))).sendKeys("Automation");
		return this;
	}


	//Select Group Type as 'Capacity'
	public WorkTypeGroup editCapacity() throws InterruptedException {
		driver.findElement(By.className("select")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.editCapacity.xpath"))).click();
		return this;
	}

	//Click on Save
	public WorkTypeGroup editWorkTypeSave() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.editWorkTypeSave.xpath"))).click();
		Thread.sleep(4000);
		return this;
	}

	//Click on 'Salesforce Automation by Your Name'and Verify Description as 'Automation'
	public WorkTypeGroup verifyWorkTypeGroupText() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.verifyWorkTypeGroupClick.xpath"))).click();
		Thread.sleep(3000);
		String verifyDescription = driver.findElement(By.xpath(prop.getProperty("WorkTypeGroup.verifyWorkTypeGroupText.xpath"))).getText();
		System.out.println(verifyDescription);
		return this;
	}
}
