package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods{

	public MyOpportunity clickOpportunity() {
		WebElement opp = driver.findElement(By.xpath(prop.getProperty("MyHomePage.clickOpportunity.xpath")));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", opp);
		return new MyOpportunity();
	}

	
	
}
