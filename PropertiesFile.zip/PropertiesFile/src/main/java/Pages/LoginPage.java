package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage enterUserName() {
		driver.findElement(By.id(prop.getProperty("LoginPage.username.Id"))).sendKeys(prop.getProperty("userName"));
		return this;
	}

	public LoginPage enterPassword() {
		driver.findElement(By.id(prop.getProperty("LoginPage.password.Id"))).sendKeys(prop.getProperty("passWord"));
		return this;
	}


	public HomePage clickLogIn() throws InterruptedException {
		driver.findElement(By.id(prop.getProperty("LoginPage.Login.Id"))).click();
		Thread.sleep(5000);
		return new HomePage();
	}


}
