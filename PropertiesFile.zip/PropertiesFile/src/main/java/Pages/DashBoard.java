package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import Base.ProjectSpecificMethods;

public class DashBoard extends ProjectSpecificMethods{

	//Select Home from the DropDown
	public DashBoard clickHomefromDropDown() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Show Navigation Menu']")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Home']")));
		return this;
	}

	//Select Dashboards from DropDown
	public DashBoard clickDashBoardfromDropDown() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.dashboardDropDownNavMenu.xpath"))));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.dashboardDropDown.xpath"))));
		Thread.sleep(5000);
		return this;
	}

	//Click on New Dashboard
	public DashBoard clickNewDashboard() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.clickNewDashBoard.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//Enter the Dashboard name as "YourName_Workout"
	public DashBoard enterNameinDashboard() throws InterruptedException {
		WebElement frame = driver.findElement(By.xpath(prop.getProperty("DashBoard.enterNameinDashboardFrame.xpath")));
		driver.switchTo().frame(frame);
		driver.findElement(By.xpath(prop.getProperty("DashBoard.enterNameinDashboard.xpath"))).sendKeys("Sivaraj");
		Thread.sleep(3000);
		return this;
	}
	//Enter Description as Testing and Click on Create
	public DashBoard enterDescriptioninDashboard() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.enterDescriptioninDashboard.xpath"))).sendKeys("Testing");
		Thread.sleep(5000);
		driver.findElement(By.id(prop.getProperty("DashBoard.clickSubmit.Id"))).click();
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		return this;
	}

	//Verify Title
	public DashBoard verifyTitle() throws InterruptedException {
		String browserTitle = driver.getTitle();
		System.out.println("Browser Title: "+browserTitle);
		Thread.sleep(5000);
		return this;
	}

	//Click on Done
	public DashBoard clickDone() throws InterruptedException {
		WebElement frame = driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDoneFrame.xpath")));
		driver.switchTo().frame(frame);
		driver.executeScript("arguments[0].click()",
				driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDone.xpath"))));
		Thread.sleep(5000);
		return this;
	}

	//Verify the Dashboard is Created
	public DashBoard verifyDashboardName()  {
		String verifyDashboard = driver.findElement(By.xpath(prop.getProperty("DashBoard.verifyDashboardName.xpath"))).getText();
		System.out.println("Dashboard Name :"+verifyDashboard);
		return this;
	}
	//Click on Subscribe
	public DashBoard clickSubscribe() throws InterruptedException  {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.clickSubscribe.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//Select Frequency as "Daily"
	public DashBoard clickDaily() throws InterruptedException  {
		driver.switchTo().defaultContent();
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDaily.xpath"))));
		Thread.sleep(5000);
		return this;
	}

	//Time as 10:00 AM
	public DashBoard chooseTime() throws InterruptedException  {
		WebElement time = driver.findElement(By.xpath(prop.getProperty("DashBoard.chooseTime.xpath")));
		Select sel = new Select(time);
		sel.selectByVisibleText("10:00 AM");
		Thread.sleep(5000);
		return this;
	}

	//Click on Save
	public DashBoard clickSubscribeSave() throws InterruptedException  {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.clickSubscribeSave.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//Verify "You started Dashboard Subscription" message displayed or not
	public DashBoard verifyDashboardSubscription() {
		String verifyName = driver.findElement(By.xpath(prop.getProperty("DashBoard.verifyDashboardSubscription.xpath"))).getText();
		System.out.println("DashBoard Subscription Veriifcation:" +verifyName);
		return this;
	}

	//Close the "YourName_Workout" tab
	public DashBoard closeWorkOutTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("DashBoard.closeWorkOutTabAct.xpath"))));
		Thread.sleep(4000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("DashBoard.closeWorkOutTab.xpath"))));
		Thread.sleep(5000);
		return this;
	}

	//Click on Private Dashboards
	public DashBoard clickPrivateDashBoards() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.clickPrivateDashBoard.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//Verify the newly created Dashboard available
	public DashBoard searchDashboardName() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("DashBoard.searchDashboardName.xpath"))).sendKeys("Sivaraj", Keys.ENTER);
		Thread.sleep(5000);
		return this;
	}

	//Click on dropdown for the item
	public DashBoard clickDropDownitem() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDropDownitem.xpath"))));
		Thread.sleep(5000);
		return this;
	}

	//Select Delete
	public DashBoard clickDelete() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDelete.xpath"))));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("DashBoard.clickDeleteClose.xpath"))));
		return this;
	}

	//Confirm the Delete
	public DashBoard confirmDelete() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.confirmDelete.xpath"))));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("DashBoard.confirmDeleteSpan.xpath"))));
		Thread.sleep(5000);
		//String deleteText = driver.findElement(By.xpath("//span[contains(text(), 'Dashboard']")).getText();
		//System.out.println("Delete Confirmation:" +deleteText);
		return this;
	}


	//Verify the item is not available under Private Dashboard folder
	public DashBoard itemNotAvailable() throws InterruptedException {
		String item = driver.findElement(By.xpath(prop.getProperty("DashBoard.itemNotAvailable.xpath"))).getText();
		System.out.println(item);
		return this;
	}

}
