package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Base.ProjectSpecificMethods;

public class Individuals extends ProjectSpecificMethods{

	//Click on the Dropdown icon in the Individuals tab
	public Individuals clickIndividualTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("Individuals.clickIndividualTab.xpath"))));
		Thread.sleep(5000);
		return this;
	}	

	//Click on New Individual
	public Individuals clickNewIndividual() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("Individuals.clickNewIndividual.xpath"))));
		Thread.sleep(3000);
		return this;
	}

	//Enter the Last Name as 'Kumar'
	public Individuals enterLastName() throws InterruptedException {
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[text()='--None--']")));
		Thread.sleep(2000);
		driver.findElement(By.xpath(prop.getProperty("Individuals.enterLastName.xpath"))).click();
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Kumar");
		return this;
	}
	//click Save
	public Individuals clickSave() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("Individuals.clickSave.xpath"))).click();
		Thread.sleep(5000);
		return this;
	}

	//Search the Individuals 'Kumar' & Click on the Dropdown icon and Select Edit
	public Individuals searchIndividuals() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("Individuals.searchIndividuals.xpath"))).sendKeys("Kumar"+Keys.ENTER);
		Thread.sleep(4000);
		return this;
	}

	//Click on the Dropdown icon and Select Edit
	public Individuals selectEdit() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("Individuals.selectEditDrop.xpath"))).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(prop.getProperty("Individuals.selectEdit.xpath"))).click();
		Thread.sleep(3000);
		return this;
	}

	//Enter the first name as 'Ganesh'.
	public Individuals enterFirstName()  {
		driver.findElement(By.xpath("//input[@class='firstName compoundBorderBottom form-element__row input']")).clear();
		driver.findElement(By.xpath(prop.getProperty("Individuals.enterFirstName.xpath"))).sendKeys("Ganesh");
		return this;
	}

	//Click on Save
	public Individuals clickEditSave() throws InterruptedException  {
		driver.findElement(By.xpath(prop.getProperty("Individuals.clickEditSave.xpath"))).click();
		Thread.sleep(4000);
		return this;
	}

	//Verify the first name as 'Ganesh'
	public Individuals verifyFirstName() throws InterruptedException  {
		String fName = driver.findElement(By.xpath(prop.getProperty("Individuals.verifyFirstName.xpath"))).getText();
		System.out.println(fName);
		return this;
	}

	//Click on the Dropdown icon and Select Delete
	public Individuals selectDelete() throws InterruptedException  {
		driver.findElement(By.xpath(prop.getProperty("Individuals.selectDeleteDrop.xpath"))).click();
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath(prop.getProperty("Individuals.selectDelete.xpath"))));
		Thread.sleep(10000);
		return this;
	}

	//Verify Whether Individual is Deleted using Individual last name
	public Individuals verifyDeleteLastName() throws InterruptedException  {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).clear();
		driver.findElement(By.xpath(prop.getProperty("Individuals.verifyDeleteLastName.xpath"))).sendKeys("Kumar"+Keys.ENTER);
		Thread.sleep(5000);
		String lName = driver.findElement(By.xpath(prop.getProperty("Individuals.verifyLastName.xpath"))).getText();
		System.out.println(lName);
		return this;
	}







}
