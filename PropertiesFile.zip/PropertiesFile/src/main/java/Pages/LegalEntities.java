package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import Base.ProjectSpecificMethods;

public class LegalEntities extends ProjectSpecificMethods {

	//Click on New Legal Entity
	public LegalEntities clickNewLegalEntity() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.clickNewLegalEntity.xpath"))).click();
		Thread.sleep(3000);
		return this;

	}
	//Enter Name as 'Salesforce Automation by Your Name'
	public LegalEntities enterNameLegalEntities() {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.enterNameLegalEntities.xpath"))).sendKeys("Salesforce Automation by Sivaraj");
		return this;
	}

	//click Save
	public LegalEntities clickSaveLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.clickSaveLegalEntities.xpath"))).click();
		Thread.sleep(3000);
		return this;
	}

	//verify Legal Entity Name
	public LegalEntities verifyLegalEntityName() {
		String verifyText = driver.findElement(By.xpath(prop.getProperty("LegalEntity.verifyLegalEntityName.xpath"))).getText();
		System.out.println(verifyText);
		return this;
	}

	//Search the Legal Entity 'Salesforce Automation by Your Name'
	public LegalEntities searchLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.searchLegalEntities.xpath"))).sendKeys("Salesforce Automation by Sivaraj"+Keys.ENTER);
		Thread.sleep(3000);
		return this;
	}

	//Click on the Dropdown icon and Select Edit
	public LegalEntities clickEditLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("LegalEntity.clickEditLegalEntities.xpath"))));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
		return this;
	}

	//Enter the Company name as 'Testleaf'
	public LegalEntities editCompanyNameinLegalEntities() {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editCompanyNameinLegalEntitiesclear.xpath"))).clear();
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editCompanyNameinLegalEntities.xpath"))).sendKeys("TestLeaf");
		return this;
	}

	//Enter Description as 'SalesForce'.
	public LegalEntities editDescriptioninLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editDescriptioninLegalEntitiesClear.xpath"))).clear();
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editDescriptioninLegalEntities.xpath"))).sendKeys("SalesForce");
		Thread.sleep(3000);
		return this;
	}

	//Select Status as 'Active'
	public LegalEntities editStatusinLegalEntities() {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editStatusinLegalEntitiesAct.xpath"))).click();
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editStatusinLegalEntities.xpath"))).click();
		return this;
	}

	//Click on Save and Verify Status as Active
	public LegalEntities editSaveinLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editSaveinLegalEntities.xpath"))).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath(prop.getProperty("LegalEntity.editSaveinLegal.xpath"))).click();
		Thread.sleep(3000);
		String status = driver.findElement(By.xpath(prop.getProperty("LegalEntity.editSaveText.xpath"))).getText();
		System.out.println(status);
		return this;
	}
}
