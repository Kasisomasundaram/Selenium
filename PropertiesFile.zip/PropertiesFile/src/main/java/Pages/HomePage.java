package Pages;

import org.openqa.selenium.By;

import Base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage clickAppLauncher() {
		driver.findElement(By.className(prop.getProperty("HomePage.Applauncher.className"))).click();
		return this;
	}


	//Click view All
	public HomePage clickViewAll() {
		driver.findElement(By.xpath(prop.getProperty("HomePage.viewAll.xpath"))).click();
		return this;
	}

	//click Sales from App Launcher
	public MyHomePage clickSales()  {
		driver.findElement(By.xpath(prop.getProperty("HomePage.sales.xpath"))).click();
		return new MyHomePage();

	}

	//click Legal Entity from App Launcher
	public LegalEntities clickLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("HomePage.legalEntities.xpath"))));
		Thread.sleep(5000);
		return new LegalEntities();

	}

	//click Service Console from App Launcher
	public DashBoard clickServiceConsole() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("HomePage.serviceConsole.xpath"))));
		Thread.sleep(5000);
		return new DashBoard();

	}

	//Click Work Type Group from App Launcher
	public WorkTypeGroup clickWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("HomePage.clickWorkTypeGroup.xpath"))));
		Thread.sleep(5000);
		return new WorkTypeGroup();
	}	

	//click Individuals from App Launcher
	public Individuals clickIndividuals() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath(prop.getProperty("Individuals.clickIndividuals.xpath"))));
		Thread.sleep(5000);
		return new Individuals();
	}
}
