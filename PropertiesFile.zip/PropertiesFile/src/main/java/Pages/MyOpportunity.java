package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import Base.ProjectSpecificMethods;

public class MyOpportunity extends ProjectSpecificMethods {

	public MyOpportunity clickNewOpportunity() {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickNewOpportunity.xpath"))).click();
		return this;

	}

	public MyOpportunity enterOpportunityName(String uName) {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.enterOpportunityName.xpath"))).sendKeys(uName);
		return this;
	}

	public MyOpportunity enterCloseDate(String cDate) {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.enterCloseDate.xpath"))).sendKeys(cDate);
		return this;
	}

	public MyOpportunity selectStage() throws InterruptedException {
		WebElement dropDown=driver.findElement(By.xpath(prop.getProperty("MyOpportunity.selectStage.xpath")));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", dropDown);
		Thread.sleep(4000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.selectStageValue.xpath"))).click();
		return this;
	}
	public MyOpportunity clickSave() {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickSave.xpath"))).click();
		return this;
	}

	//Search the Opportunity
	public MyOpportunity searchOpportunity() throws InterruptedException {
		WebElement search = driver.findElement(By.xpath(prop.getProperty("MyOpportunity.searchOpportunity.xpath")));
		search.sendKeys("Salesforce Automation by Sivaraj");
		search.sendKeys(Keys.ENTER);
		Thread.sleep(4000);
		return this;
	}

	//Click the edit button
	public MyOpportunity clickEditButton() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickEditButtonDrop.xpath"))).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickEditButton.xpath"))).click();
		Thread.sleep(3000);
		return this;
	}

	//Choose close date as Tomorrow date
	public MyOpportunity editCloseDate() {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editCloseDateClear.xpath"))).clear();
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editCloseDate.xpath"))).sendKeys("11/14/2021");
		return this;
	}

	//Select 'Stage' as Perception Analysis
	public MyOpportunity editStage() throws InterruptedException {
		WebElement dropDown=driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editStageChoose.xpath")));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", dropDown);
		//Another way for Java Executor 
		//driver.executeScript("arguments[0].click();",driver.findElement(By.xpath("(//input[@class='slds-input slds-combobox__input'])[4]")));
		Thread.sleep(2000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editStage.xpath"))).click();
		return this;
	}

	//Select Deliver Status as In Progress
	public MyOpportunity editDeliveryStatus() throws InterruptedException {
		WebElement delivery = driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editDeliveryStatus.xpath")));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", delivery);
		Thread.sleep(2000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editDelivery.xpath"))).click();
		return this;
	}

	//Enter Description as SalesForce
	public MyOpportunity editDescription() {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editDescription.xpath"))).sendKeys("SalesForce");
		return this ;
	}

	//Click on Save
	public MyOpportunity editSave() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.editSave.xpath"))).click();
		Thread.sleep(4000);
		return this;
	}

	//Verify Stage as Perception Analysis
	public MyOpportunity stageText() {
		String perception = driver.findElement(By.xpath(prop.getProperty("MyOpportunity.stageText.xpath"))).getText();
		System.out.println(perception);
		return this;
	}

	//click Delete button
	public MyOpportunity clickDelete() throws InterruptedException {
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickDelete1.xpath"))).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickDelete2.xpath"))).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(prop.getProperty("MyOpportunity.clickDelete3.xpath"))).click();
		return this;
	}

	//Vereify the text matches
	public MyOpportunity verifyText() throws InterruptedException {
		WebElement verifyText = driver.findElement(By.xpath(prop.getProperty("MyOpportunity.verifyText1.xpath")));
		verifyText.sendKeys("Salesforce Automation by Sivaraj");
		verifyText.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		String nomatches = driver.findElement(By.xpath(prop.getProperty("MyOpportunity.verifyText2.xpath"))).getText();
		System.out.println(nomatches);
		return this;
		
	}
}