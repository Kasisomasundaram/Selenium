package parallelRun;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditOpportunity extends Driver{

	
	@And ("Search the Opportunity Name as {string}")
	public void searchOpportunity(String searchName) throws InterruptedException {
		WebElement search = driver.findElement(By.xpath("//input[@placeholder='Search this list...']"));
		search.sendKeys(searchName);
		search.sendKeys(Keys.ENTER);
		Thread.sleep(4000);
	}

	@And ("Click the edit button")
	public void clickEditButton() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
	}

	@And ("Choose close date as {string}")
	public void editCloseDate(String tDate) {
		driver.findElement(By.xpath("//input[@name='CloseDate']")).clear();
		driver.findElement(By.xpath("//input[@name='CloseDate']")).sendKeys(tDate);
	}
	
	@And ("Select Stage as Perception Analysis")
	public void editStage() throws InterruptedException {
	WebElement dropDown=driver.findElement(By.xpath("(//input[@class='slds-input slds-combobox__input'])[4]"));
	JavascriptExecutor executor1 = (JavascriptExecutor)driver;
	executor1.executeScript("arguments[0].click();", dropDown);
	Thread.sleep(2000);
	driver.findElement(By.xpath("//span[@title='Perception Analysis']")).click();
	}
	
	@And ("Select Deliver Status as In Progress")
	public void editDeliveryStatus() throws InterruptedException {
		WebElement delivery = driver.findElement(By.xpath("//label[text()='Delivery/Installation Status']/following::input"));
		JavascriptExecutor executor2 = (JavascriptExecutor)driver;
		executor2.executeScript("arguments[0].click();", delivery);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@title='In progress']")).click();
	}
	
	@And ("Enter Description as SalesForce")
	public void editDescription() {
		driver.findElement(By.xpath("//textarea[@class='slds-textarea']")).sendKeys("SalesForce");
		
	}
	
	@When ("Click on Save")
	public void editSave() throws InterruptedException {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		Thread.sleep(4000);
	}
	
	@Then ("Verify Stage as Perception Analysis")
	public void stageText() {
		String perception = driver.findElement(By.xpath("//span[text()='Perception Analysis']")).getText();
		System.out.println(perception);
		}
}
