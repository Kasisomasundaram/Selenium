package parallelRun;

import org.openqa.selenium.remote.RemoteWebDriver;


public class Driver {
	
	public static RemoteWebDriver driver;

}
