package parallelRun;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateOpportunity extends Driver {

	
	@And ("Click on New Opportunity")
	public void clickNewOpportunity() throws InterruptedException {
		driver.findElement(By.xpath("//div[@title='New']")).click();
		Thread.sleep(5000);


	}
	@And ("Enter Opportunity Name as {string}")
	public void enterOpportunityName(String fName) {
		driver.findElement(By.xpath("//label[text()='Opportunity Name']/following::input")).sendKeys(fName);

	}
	@And ("Enter Close Date as {string}")
	public void enterCloseDate(String cDate) {
		driver.findElement(By.xpath("(//input[@class='slds-input'])[3]")).sendKeys(cDate);

	}
	@When ("Choose the Stage")
	public void selectStage() throws InterruptedException {
		WebElement dropDown=driver.findElement(By.xpath("(//input[@class='slds-input slds-combobox__input'])[3]"));
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", dropDown);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[@title='Needs Analysis']")).click();
		Thread.sleep(5000);

	}

	@Then ("Click on Save button")
	public void clickSave() throws InterruptedException {
		driver.findElement(By.xpath("//button[@name='SaveEdit']")).click();
		Thread.sleep(5000);

	}

}

