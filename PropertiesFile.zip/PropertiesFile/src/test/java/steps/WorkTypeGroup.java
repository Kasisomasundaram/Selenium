package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WorkTypeGroup extends Driver {

	@And ("Click on the Dropdown icon in the Work Type Groups tab")
	public void clickWorkTypeGroupTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("(//span[contains(text(),'Work Type Groups')])[3]")));
		Thread.sleep(5000);
	}

	@And ("Click on New Work Type Group")
	public void clickNewWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='New Work Type Group']")));
		Thread.sleep(3000);
	}

	@And ("Enter Work Type Group Name as {string}")
	public void enterWorkTypeName(String fName) {
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys(fName);
	}

	@When ("Click Save on work Type Group")
	public void clickSaveWorkTypeGroup() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(5000);
	}

	@Then ("Verify Work Type Group Name")
	public void verifyWorkTypeGroupName() {
		String verifyText = driver.findElement(By.xpath("(//span[@class='uiOutputText'])[2]")).getText();
		System.out.println(verifyText); 
	}

	@And ("Search the Work Type Group as {string}")
	public void searchWorkTypeGroupName(String searchName) throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(searchName +Keys.ENTER);
		Thread.sleep(4000);
	}

	@And ("Click on the Dropdown icon and Select Edit in Work Type Group")
	public void clickEditInWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")));
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[@title='Edit']")));
		Thread.sleep(3000);
	}

	@And ("Enter Description as {string}")
	public void enterDescription(String description) {
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).clear();
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).sendKeys(description);
	}

	@And ("Select Group Type")
	public void selectGroup() throws InterruptedException {
		driver.findElement(By.className("select")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@title='Capacity']")).click();
	}

	@When ("Click on Save Work Type Group")
	public void clickSaveforEdit() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(4000);
	}

	@Then ("Click on Salesforce Automation by Your Name and Verify Description as Automation")
	public void verifyEditText() throws InterruptedException {
		driver.findElement(By.xpath("(//a[@data-aura-class='forceOutputLookup'])[1]")).click();
		Thread.sleep(3000);
		String verifyDescription = driver.findElement(By.xpath("//span[@data-aura-class='uiOutputTextArea']")).getText();
		System.out.println(verifyDescription);
	}

	@And ("Click on the Dropdown icon and Select Delete on WorkType Group")
	public void clickDeleteWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")));
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[@title='Delete']")));
		Thread.sleep(3000);
	}

	@When ("Click on the Delete option in the displayed popup window.")
	public void clickDeletePopupWindow() {
		driver.findElement(By.xpath("//button[@title='Delete']")).click();
	}

	@Then ("Verify Whether Work Type group is Deleted using Work Type Group Name") 
	public void verifyDeleteWorkTypeGroupName() throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys("Salesforce Automation by Sivaraj"+Keys.ENTER);
		Thread.sleep(3000);
		String nomatches = driver.findElement(By.xpath("//span[text()='No items to display.']")).getText();
		System.out.println(nomatches);
	}

}
