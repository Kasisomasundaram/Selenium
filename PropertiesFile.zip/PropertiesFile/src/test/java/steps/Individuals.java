package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Individuals extends Driver {

	@And ("Click on the Dropdown icon in the Individuals tab")
	public void clickIndividualTab() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[contains(text(),'Individuals Menu')]")));
		Thread.sleep(5000);

	}

	@And ("Click on New Individual")
	public void newIndividuals() throws InterruptedException {
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='New Individual']")));
		Thread.sleep(3000);
	}

	@And ("Enter the Last Name as {string}")
	public void enterLastName(String lName) throws InterruptedException {
		driver.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[text()='--None--']")));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@title='Mr.']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lName);
	}


	@When ("click Save")
	public void clickSave() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(5000);

	}
	
	@And ("Search the Individuals Name")
	public void searchIndividualName() throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys("Kumar"+Keys.ENTER);
		Thread.sleep(4000);
	}

	@And ("Click on the Dropdown icon and Select Edit")
	public void clickEdit() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
	}
	@And ("Enter the first name as {string}")
	public void enterFirstName(String fName) {
		driver.findElement(By.xpath("//input[@class='firstName compoundBorderBottom form-element__row input']")).clear();
		driver.findElement(By.xpath("//input[@class='firstName compoundBorderBottom form-element__row input']")).sendKeys(fName);
	}
	@When ("Click on Save Button")
	public void save() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(4000);
	}
	
	
	@Then ("Verify the first name")
	public void verifyFirstName() {
		String fName = driver.findElement(By.xpath("(//a[contains(@class,'slds-truncate outputLookupLink')])[1]")).getText();
		System.out.println(fName);
	}
	
	@And ("Search the Individuals Name as {string}")
	public void individualName(String searchName) throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(searchName +Keys.ENTER);
		Thread.sleep(4000);
	}
	
	@When ("Click on the Dropdown icon and Select Delete")
	public void clickDelete() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")).click();
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//div[text()='Delete']")));
		Thread.sleep(10000);
	}
	
	@Then ("Verify Whether Individual is Deleted using Individual last name")
	public void verifyLastName() {
		String lName = driver.findElement(By.xpath("//span[text()='No items to display.']")).getText();
		System.out.println(lName);	
	}
}
