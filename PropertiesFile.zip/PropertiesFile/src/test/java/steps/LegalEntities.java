package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LegalEntities extends Driver{


	@And ("Click on New Legal Entity")
	public void clickNewLegalEntity() throws InterruptedException {
		driver.findElement(By.xpath("//div[text()='New']")).click();
		Thread.sleep(3000);
	}

	@And ("Enter Name as {string}")
	public void enterNameLegalEntities(String legalName) throws InterruptedException {
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys(legalName);
		Thread.sleep(3000);
	}

	@When ("click Save on Legal Entity")
	public void clickSaveLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(3000);
	}

	@Then ("Verify Legal Entity Name")
	public void verifyLegalEntityName() {
		String verifyText = driver.findElement(By.xpath("(//span[@class='uiOutputText'])[3]")).getText();
		System.out.println(verifyText);
	}

	@And ("Search the Legal Entity  as {string}")
	public void searchLegalEntities(String SearchName) throws InterruptedException {
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(SearchName +Keys.ENTER);
		Thread.sleep(3000);
	}

	@And ("Click on the Dropdown icon and Select Edit on Legal Entity")
	public void clickEditLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Edit']")).click();
		Thread.sleep(3000);
	}

	@And ("Enter the Company name as {string}")
	public void editCompanyNameinLegalEntities(String companyName) {
		driver.findElement(By.xpath("(//input[@class=' input'])[2]")).clear();
		driver.findElement(By.xpath("(//input[@class=' input'])[2]")).sendKeys(companyName);
	}

	@And ("Enter Description on Legal Entities as {string}")
	public void enterDescriptioninLegalEntities(String Description) throws InterruptedException {
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).clear();
		driver.findElement(By.xpath("//textarea[@class=' textarea']")).sendKeys(Description);
		Thread.sleep(3000);

	}

	@And ("Select Status as Active")
	public void editStatusinLegalEntities() {
		driver.findElement(By.xpath("//a[@class='select']")).click();
		driver.findElement(By.xpath("//a[text()='Active']")).click();

	}
	@When ("Click on Save and Verify Status as Active")
	public void editSaveinLegalEntities() throws InterruptedException {
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//a[contains(@class,'slds-truncate outputLookupLink')]")).click();
		Thread.sleep(3000);
		String status = driver.findElement(By.xpath("//span[text()='Active']")).getText();
		System.out.println(status);

	}

}
