package steps;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;



public class BaseClass extends Driver{
	

	@Before
	public void preCondition() throws InterruptedException {

		
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(options);

		//Launch the SalesForce URL
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");
		
		
		driver.findElement(By.id("password")).sendKeys("SelBootcamp$1234");
		
		driver.findElement(By.id("Login")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.className("slds-r5")).click();
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(5000);

	}

	@After
	public void postCondition() {
		driver.close();
	}

}
