package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

public class HomePage extends Driver{

	
	@Given ("Click on Sales")
	public void clickSales() throws InterruptedException  {
		driver.findElement(By.xpath("//p[text()='Sales']")).click();
		Thread.sleep(5000);
	}
 
	@And ("Click on Opportunity")
	public void clickOpportunity() {
		WebElement opp = driver.findElement(By.xpath("//span[text()='Opportunities']"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", opp);

	}
	@Given ("Click on Individuals")
	public void clickIndividuals() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Individuals']")));
		Thread.sleep(5000);
	}
	@Given ("Click on Work Type Groups")
	public void clickWorkTypeGroup() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Work Type Groups']")));
		Thread.sleep(5000);
	}
	
	@Given ("Click on Legal Entity from App Launcher")
	public void clickLegalEntities() throws InterruptedException {
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//p[text()='Legal Entities']")));
		Thread.sleep(5000);
		
	}
	
}
