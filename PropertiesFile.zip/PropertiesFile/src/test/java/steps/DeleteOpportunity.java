package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteOpportunity extends Driver{


	@And ("Search the Opportunity Name for Delete as {string}")
	public void searchOpportunity(String deleteName) throws InterruptedException {
		WebElement search = driver.findElement(By.xpath("//input[@placeholder='Search this list...']"));
		search.sendKeys(deleteName);
		search.sendKeys(Keys.ENTER);
		Thread.sleep(4000);
	}

	@When ("Click on the Drop down icon and Select Delete")
	public void clickDeleteButton() throws InterruptedException {
		driver.findElement(By.xpath("//span[@class='slds-icon_container slds-icon-utility-down']//span")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@title='Delete']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		Thread.sleep(3000);
	}

	@Then ("Verify the text No Matches found")
	public void verifyText() {
		WebElement verifyText = driver.findElement(By.xpath("//input[@placeholder='Search this list...']"));
		verifyText.sendKeys("Salesforce Automation by Sivaraj");
		verifyText.sendKeys(Keys.ENTER);
		String nomatches = driver.findElement(By.xpath("//span[text()='No items to display.']")).getText();
		System.out.println(nomatches);
	}

}
