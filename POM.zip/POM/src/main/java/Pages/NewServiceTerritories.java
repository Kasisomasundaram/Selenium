package Pages;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import Base.BaseClass;


public class NewServiceTerritories extends BaseClass {
	
	public NewServiceTerritories() {
		PageFactory.initElements(driver, this); 
	}
	
	@FindBy(how=How.XPATH, using="//input[@class=' input']")  WebElement enterName;
	@FindBy(how=How.XPATH, using="//input[@placeholder='Search Operating Hours...']")  WebElement enterHour;
	@FindBy(how=How.XPATH, using="//div[@title='UK Shift']")  WebElement selectUK;
	@FindBy(how=How.XPATH, using="(//input[@type='checkbox'])[2]")  WebElement active;
	@FindBy(how=How.XPATH, using="//textarea[@placeholder='Address']")  WebElement address;
	@FindBy(how=How.XPATH, using="//input[@placeholder='City']")  WebElement city;
	@FindBy(how=How.XPATH, using="//input[@placeholder='Zip/Postal Code']")  WebElement zipcode;
	@FindBy(how=How.XPATH, using="//input[@placeholder='State/Province']")  WebElement state;
	@FindBy(how=How.XPATH, using="//input[@placeholder='Country']")  WebElement country;
	@FindBy(how=How.XPATH, using="(//span[text()='Save'])[2]")  WebElement clickSave;
	
	
	public NewServiceTerritories enterName()  {
		clearAndType(enterName, "Automation Testing");
		takeSnap();		
		return this;
	}
	
	public NewServiceTerritories enterHour() {
		click(enterHour);
		click(selectUK);
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories active() {
		click(active);
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories address() {
		clearAndType(address, "Kattupakkam");
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories city() {
		clearAndType(city, "Chennai");
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories zipcode() {
		clearAndType(zipcode,"600056");
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories country() {
		clearAndType(country,"India");
		takeSnap();
		return this;
		
	}
	
	public NewServiceTerritories state() {
		clearAndType(state, "Tamilnadu");
		takeSnap();
		return this;
		
	}
	
	
	public ServiceTerritories clickSave() {
		click(clickSave);
		takeSnap();
		return new ServiceTerritories();
		
	}
}