package Pages;

import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import Base.BaseClass;


public class ServiceTerritories extends BaseClass {
	
	public ServiceTerritories() {
		PageFactory.initElements(driver, this); 
	}
	
	@FindBy(how=How.XPATH, using="//div[text()='New']")  WebElement clickNew;
	@FindBy(how=How.XPATH, using="//span[@class='toastMessage slds-text-heading--small forceActionsText']")  WebElement seriveCreated;
	@FindBy(how=How.XPATH, using="//div[@class='slds-icon-waffle']")  WebElement clickAppLauncher;
	@FindBy(how=How.XPATH, using="//a[starts-with(@class, 'slds-truncate outputLookupLink slds-truncate')]")  WebElement nameVerification;
	
	public NewServiceTerritories clickNew()  {
		click(clickNew);
		takeSnap();		
		return new NewServiceTerritories();
	}

	public ServiceTerritories serviceCreated()  {
		getElementText(seriveCreated);
		takeSnap();		
		return this;
	}
	
	public HomePage clickAppLauncher()  {
		click(clickAppLauncher);
		takeSnap();		
		return new HomePage();
	}
	
	public ServiceTerritories nameVerification()  {
		getElementText(nameVerification);
		takeSnap();		
		return this;
	}
	
	
	
	
}