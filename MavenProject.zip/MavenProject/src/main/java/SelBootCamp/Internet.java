package SelBootCamp;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Internet {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.iedriver().arch32().setup();
		InternetExplorerDriver driver = new InternetExplorerDriver();
		driver.get("https://login.salesforce.com");
	}

}
