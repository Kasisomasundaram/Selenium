package SelBootCamp;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;

public class FirefoxDriver {
	
		@SuppressWarnings("deprecation")
		public static void main(String[] args) throws InterruptedException {

			//ChromeOptions options=new ChromeOptions();
			//options.addArguments("--disable-notifications");
			WebDriverManager.firefoxdriver().setup();
			FirefoxDriver driver = new FirefoxDriver();
			((WebDriver) driver).get("https://login.salesforce.com");
			((WebDriver) driver).manage().window().maximize();
			/*WebDriverManager.edgedriver().setup();
			EdgeDriver driver = new EdgeDriver();
			driver.get("https://login.salesforce.com");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);*/
			
			
			
}

			
		}