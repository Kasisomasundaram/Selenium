package SelBootCamp;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Assertion {
	@Test
	public void testAssertfunction() {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");

		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver(options);
		SoftAssert softAssert = new SoftAssert();
		driver.navigate().to("https://www.browserstack.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		boolean displayed = driver.findElement(By.linkText("Get started free")).isDisplayed();
		String ExpectedTitle = "Most Reliable App & Cross Browser Testing Platform | BrowserStack";
		String getActualTitle = driver.getTitle();
		System.out.println("Page Title is "+getActualTitle);
//		boolean verifyTitle = driver.getTitle().equalsIgnoreCase("Most Reliable App & Cross Browser Testing Platform | BrowserStack");
		softAssert.assertEquals(getActualTitle, ExpectedTitle);
		softAssert.assertFalse(displayed);
//		softAssert.assertNotEquals(getActualTitle, "Most Reliable App & Cross Browser Testing Platform | BrowserStack");
//		softAssert.assertNotNull(ExpectedTitle);
//		softAssert.assertNull(ExpectedTitle);
//		softAssert.assertTrue("BrowserStack".equals("Browserstack"), "First soft assert failed");
//		softAssert.assertFalse("BrowserStack".equals("Browserstack"), "First soft assert failed");
		softAssert.assertAll();	
		driver.close();

	}

}	
