package SelBootCamp;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


import io.github.bonigarcia.wdm.WebDriverManager;

public class TC024_WeeklyAssignment_ServiceConsole {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException, AWTException {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver(options);

		//Launch the SalesForce URL
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);

		//Enter the user name
		driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");

		//Enter the Password
		driver.findElement(By.id("password")).sendKeys("SelBootcamp$1234");

		//Click on Login button
		driver.findElement(By.id("Login")).click();
		Thread.sleep(4000);

		//Click on toggle menu button 
		driver.findElement(By.className("slds-r5")).click();
		Thread.sleep(5000);

		//Click view All
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(3000);

		//Click Service Console from App Launcher
		driver.findElement(By.xpath("//p[text()='Service Console']")).click();
		Thread.sleep(5000);

		//Select Files from the DropDown
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Show Navigation Menu']")));
		Thread.sleep(3000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//span[text()='Files']")));
		Thread.sleep(4000);

		//Click on the latest modified item link
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[contains(@class,'slds-button slds-button--icon-x-small')]")));
		Thread.sleep(5000);

		//Click on Public link
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[text()='Public Link']")));
		Thread.sleep(5000);

		//Verify the new link text field is disabled to create public link
		boolean textField = driver.findElement(By.xpath("//input[contains(@placeholder,'No public link created')]")).isDisplayed();
		//Assert.assertEquals(textField,false);
		System.out.println("The Text Field is display  " +textField);	
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()",driver.findElement(By.xpath("//span[text()='Close this window']")));

		//Download the file into a specified folder inside the project
		String DownloadFileName = driver.findElement(By.xpath("//span[@class='itemTitle desktop outputTextOverride uiOutputText']")).getText();
		System.out.println("Before Download File Name as "+DownloadFileName);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[contains(@class,'slds-button slds-button--icon-x-small')]")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[text()='Download']")));
		Thread.sleep(5000);

		//Click on Share
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[contains(@class,'slds-button slds-button--icon-x-small')]")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[text()='Share']")));
		Thread.sleep(4000);

		
		//Click on search user and select the Derrick Dsouza
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//input[@title='Search People']")));
		driver.findElement(By.xpath("//div[text()='Derrick Dsouza']")).click();
		Thread.sleep(3000);

		//Verify the Error message "Can't share file with the file owner."
		String errorMessage = driver.findElement(By.xpath("//ul[contains(@class,'has-error uiInputDefaultError uiInput forceSearchInputLookupDesktop')]")).getText();
		System.out.println("The Error Message as "+errorMessage);

		//Remove Derrick Dsouza and Select the second user in the list
		driver.findElement(By.xpath("//span[@class='deleteIcon']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//lightning-icon[contains(@class, 'closeIcon slds-button__icon slds-button__icon--large slds-icon-utility-close')]")).click();
		Thread.sleep(3000);		


		//14. Add a message as "Bootcamp_Nupela_<your name>"
		//15. Verify "You shared <item> with <shared user>" message
		 
		 
		//16. Click on Upload Files and browse a file from your local 
		driver.findElement(By.xpath("//div[text()='Upload Files']")).click();
		Thread.sleep(3000);
		StringSelection ss = new StringSelection("C:\\Users\\SIVARAJELANGOVAN\\Downloads\\"+DownloadFileName); 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		Robot robot = new Robot(); 

		// Enter to confirm it is uploaded 
		robot.delay(3000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.keyPress(KeyEvent.VK_CONTROL);	
		robot.keyPress(KeyEvent.VK_V); 

		robot.keyRelease(KeyEvent.VK_V); 
		robot.keyRelease(KeyEvent.VK_CONTROL); 
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.delay(2000);
		Thread.sleep(5000);

		//robot.keyPress(KeyEvent.VK_ENTER); 
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[text()='Done']")).click();
		Thread.sleep(5000);

		//17. Click on DrowDown for the newly uploaded file and select View File Details
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[contains(@class,'slds-button slds-button--icon-x-small')]")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[text()='View File Details']")));
		Thread.sleep(5000);

		//18. Verify the file name and extension of the newly uploaded file
		String fileName = driver.findElement(By.xpath("//div[text()='File']//following::span")).getText();
		System.out.println("The File name as " +fileName);
		String extension = driver.findElement(By.xpath("//span[@title = 'File Extension']//following::div/div/span")).getText();
		System.out.println("The File Extension as "+extension);

		//19. Close the file window tab
		driver.findElement(By.xpath("//button[contains(@title ,'Close')]")).click();
		Thread.sleep(3000);
	
		//20. Click on DrowDown for the newly uploaded file and select Delete
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//a[contains(@class,'slds-button slds-button--icon-x-small')]")));
		Thread.sleep(5000);
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("//div[text()='Delete']")));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[text()='Delete']")).click();
		Thread.sleep(3000);
		//21. Confirm Delete

		/*
		if(fileName.equalsIgnoreCase(DownloadFileName)) {
			System.out.println("Download File is deleted");
		}else if (fileName.equalsIgnoreCase(fileName)) {
			System.out.println("Downlaod file is not deleted");
		}
		*/	

		//22. Verify the success message displayed for the delete
		String successMessage = driver.findElement(By.xpath("//span[contains(@class, 'toastMessage slds-text-heading--small')]")).getText();
		System.out.println("Success Message for Deletion as "+successMessage);
	}

}
