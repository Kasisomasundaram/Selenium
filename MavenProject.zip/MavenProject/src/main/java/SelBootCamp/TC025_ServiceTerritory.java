package SelBootCamp;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC025_ServiceTerritory {

	public static void main(String[] args) throws InterruptedException {

		//1) Launch the app

		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disable-notifications");
		WebDriverManager.chromedriver().setup();
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://login.salesforce.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);

		//2) Click Login  & //3) Login with the credentials
		driver.findElement(By.id("username")).sendKeys("makaia@testleaf.com");
		driver.findElement(By.id("password")).sendKeys("SelBootcamp@1234");
		driver.findElement(By.id("Login")).click();
		Thread.sleep(4000);
		//4) Click on the App Laucher Icon left to Setup
		driver.findElement(By.className("slds-r5")).click();
		Thread.sleep(5000);
		//5) Click on View All
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(3000);
		//6) Type service in text box
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys("service");
		Thread.sleep(3000);
		//7) Get the all the elements under All items section, find the     Service territories and click on it.
		String allItems = driver.findElement(By.xpath("(//div[@class='slds-accordion__content'])[2]")).getText();
		System.out.println(allItems);
		if(allItems.contains("Service Territories")) {
			driver.findElement(By.xpath("//p[text()=' Territories']")).click();
			Thread.sleep(3000);
		}else {
			System.out.println("Service Territories link is not Present");
		}
		//8) Click on New
		driver.findElement(By.xpath("//div[text()='New']")).click();
		Thread.sleep(5000);

		//9) Verify the mandatory fields in the New Service Territory creation form
		WebElement mandatoryName = driver.findElement(By.xpath("//span[text()='Name']/following-sibling::span"));
		if (mandatoryName.isDisplayed()) {
			System.out.println("Name Mandatory Field as "+mandatoryName.getText());
		} else {
			System.out.println("Name is not Mandatory Field");
		}
			
		
		WebElement mandatoryHours = driver.findElement(By.xpath("//span[text()='Operating Hours']/following-sibling::span"));
		if (mandatoryHours.isDisplayed()) {
			System.out.println("Operating Hours Mandatory Field as "+mandatoryHours.getText());
		}else {
			System.out.println("Operating Hours is not Mandatory Field");
		}
		
	
		//10) Enter Your Name in Name field
		driver.findElement(By.xpath("//input[@class=' input']")).sendKeys("Automation Testing");

		//11) Click on Operating Hours and Choose UK Shift Option
		driver.findElement(By.xpath("//input[@placeholder='Search Operating Hours...']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[@title='UK Shift']")).click();
		Thread.sleep(3000);
		
		//12) Verify the active field is checked or not, if not checked please check it.
		WebElement activeCheck = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
		System.out.println(activeCheck.isSelected());
		driver.executeScript("arguments[0].click()", driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")));

		//13) Again verify the active field is checked--- yes
		WebElement checkBoxChecking = driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
		System.out.println(checkBoxChecking.isSelected());

		//14) Enter the City your residing in City Field
		driver.findElement(By.xpath("//textarea[@placeholder='Address']")).sendKeys("Kattupakkam, Chennai"+Keys.TAB);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[@placeholder='City']")).sendKeys("Chennai");
		//15) Enter the State your residing in State Field
		driver.findElement(By.xpath("//input[@placeholder='State/Province']")).sendKeys("TamilNadu");
		//16) Enter the Country your residing in Country Field
		driver.findElement(By.xpath("//input[@placeholder='Country']")).sendKeys("India");
		//17) Enter your current Postal Zip Code
		driver.findElement(By.xpath("//input[@placeholder='Zip/Postal Code']")).sendKeys("600056");
		//18) Click on Save
		driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
		Thread.sleep(5000);

		//19) Verify Service Territory is created Successfully
		String seriveCreated = driver.findElement(By.xpath("//span[@class='toastMessage slds-text-heading--small forceActionsText']")).getText();
		System.out.println("Success Message as "+seriveCreated);
		driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[text()='View All']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@placeholder='Search apps or items...']")).sendKeys("service");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//p[text()=' Territories']")).click();
		Thread.sleep(3000);
		String nameVerification = driver.findElement(By.xpath("//a[starts-with(@class, 'slds-truncate outputLookupLink slds-truncate')]")).getText();
		System.out.println("The name is displayed as "+nameVerification);
		driver.close();
	}

}
