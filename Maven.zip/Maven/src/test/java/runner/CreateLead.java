package runner;

import org.testng.annotations.BeforeTest;
import com.yalla.testng.api.base.Annotations;
import cucumber.api.CucumberOptions;


@CucumberOptions(features ="src/test/java/features/CreateLead.feature" , glue ="com.yalla.pages", monochrome = true 
				/*dryRun = true, snippets=SnippetType.CAMELCASE*/)

public class CreateLead extends  Annotations{
	
	@BeforeTest
	public void setData() {
		testcaseName = "TC01_CreateLead";
		testcaseDec = "Create Lead";
		author = "Sivaraj";
		category = "smoke";

	}
	
}
