package ParaDataProvider;

import org.testng.annotations.Test;

public class BaseUtilsTest {
  @Test
  public void f() {
  }
}
