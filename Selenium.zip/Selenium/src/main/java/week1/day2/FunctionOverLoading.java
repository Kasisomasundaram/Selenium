package week1.day2;

public class FunctionOverLoading {

	public int area (int a) {
		return (a*a*a*a);
	}
	public int area (int a, int b)
	{
		return (a*b);
	}
	public float area (int a, float b) {
		return (a*a*b);
	}
	public static void main(String[] args) {

		FunctionOverLoading load = new FunctionOverLoading();
		System.out.println(load.area(5, 6.8f));

	}

}
