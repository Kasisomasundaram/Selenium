package week1.day2;

public class Palindrome {

	public static void main(String[] args) {

		String name = "malayalam";
		String rvr ="";
		char[] charArray = name.toCharArray();
		for (int i = charArray.length-1 ; i>=0; i--) {
			char c = charArray[i];
			rvr = rvr+c;
		}		
		if (name.equals(rvr)) {
			System.out.println("The above name is Palindrome  "+name);
		}else
			System.out.println("The above name is not Palindrome "+name);


	}

}

