package week1.day2;

public class ReverseCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String MyCompany = "IBM India PVT";
		String[] split = MyCompany.split(" ");
		for (int i=0; i<split.length; i++) 
		{
			System.out.print(split[i]);
		}
		char[] charArray = MyCompany.toCharArray();
		int j=0;
		for (int i=0; i<charArray.length; i++) {
			if (charArray[i] == 'I') {
				j++;		
			}
			
		}
		System.out.println(j);
	}

}
