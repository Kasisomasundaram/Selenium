package week1.day2;

public class ConstructorOverLoading {

	public ConstructorOverLoading () {
		System.out.println("No Argument");
	}
	public ConstructorOverLoading (int a)
	{
		this();
		System.out.println("Single Argument");
	}
	public ConstructorOverLoading (int a, float b) {
		this(1);
		System.out.println("Double with different Argument ");
	}
	public static void main(String[] args) {

		ConstructorOverLoading load = new ConstructorOverLoading(5,6.5F);
        

	}

}
