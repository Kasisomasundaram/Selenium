package week1.day1;

public class Vehicle {

	String modeOfVehicle = "Honda";
	char firstCharaceter = 'H';
	boolean applybreak = true;
	int wheels = 2;

	public void applyBreak () {
		System.out.println("Break Applied  " + applybreak);
	}

	public int getNumberOfWheels() {
		return wheels;
	}
	public void vehicleIsPuncher() {
		System.out.println("Not Punchered");
	}


	public static void main (String [] args) {

		Vehicle veh = new Vehicle();
		veh.applyBreak();
		int numberOfWheels = veh.getNumberOfWheels();
		System.out.println(numberOfWheels);
		veh.vehicleIsPuncher();
		char firstCharaceter2 = veh.firstCharaceter;
		System.out.println(firstCharaceter2);



	}
}