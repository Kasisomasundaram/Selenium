package week1.day1;

import org.apache.commons.collections4.functors.SwitchClosure;

public class Looping {

	public void vehicleType(String vehicle) {

		if (vehicle.equals("4 wheeler")) {
			System.out.println("four Wheeler");
		}else if (vehicle.equals("2 wheeler"))
		{
			System.out.println("Two Wheeler");

		}else if (vehicle.equals("3 Wheeler"))
		{
			System.out.println("Three Wheeler");
		} 
		
	/*	switch (vehicle) {
		case "4 wheeler":
			System.out.println("Four wheeler");
			break;
		case "2 wheeler": System.out.println("Two Wheeler");
		break;
		case "3 Wheeler" : System.out.println("Three Wheeler");
		break;
		default: System.out.println("Not Avaiable");
		break;
		}*/
	}

	public static void main (String [] args) {
		Looping veh = new Looping();
		veh.vehicleType("3 Wheeler");
		
	}
}