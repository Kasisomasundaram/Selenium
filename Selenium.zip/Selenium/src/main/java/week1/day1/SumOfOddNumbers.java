package week1.day1;

public class SumOfOddNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		for (int i=0; i<=20; i++)
		{
			if (i % 2 != 0)
			{
				sum = sum + i;
			}
		}
		System.out.println( "The sum of Odd Number  " +sum);
	}

}
