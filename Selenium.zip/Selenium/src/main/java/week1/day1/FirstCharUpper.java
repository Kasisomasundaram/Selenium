package week1.day1;

public class FirstCharUpper {

	public void Upper() {

		String str = "welcome to testleaf software";
		char[] ch = str.toCharArray();
		for (int i=0;i<ch.length;i++) {
			if (i ==0) {
				System.out.print(Character.toUpperCase(ch[i]));
			}else if(ch[i] == ' ') {
				System.out.print(" "+Character.toUpperCase((ch[i+1])));
				i=i+1;
			}else {
				System.out.print(ch[i]);
			}
				
		}
	}

	public static void main(String[] args) {
		FirstCharUpper up = new FirstCharUpper();
		up.Upper();



	}

}
