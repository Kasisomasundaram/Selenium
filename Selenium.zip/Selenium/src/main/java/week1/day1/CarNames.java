package week1.day1;

import java.util.Arrays;


public class CarNames {



	public void allCarNames()
	{
		String  car[] = {"BMW", "Audi", "Honda", "Ford", "Hyundai"};

		for (int i=0; i<car.length; i++)
			System.out.println(car[i]);

		Arrays.sort(car);
		for (int i=0; i<car.length; i++)
			System.out.println(car[i]);
	}


	public static void main(String[] args) {
		CarNames mob = new CarNames ();
		mob.allCarNames();
	}
}
