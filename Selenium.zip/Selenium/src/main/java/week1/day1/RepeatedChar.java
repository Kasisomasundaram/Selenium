package week1.day1;

public class RepeatedChar {

	public void yourName() {
		String str ="abcdabuio";
		for (int i=0; i<str.length();i++) {
			for (int j=i+1;j<str.length();j++) {
				if (str.charAt(i) == str.charAt(j)) {
					System.out.println(str.charAt(j));
					break;
				}
			}

		}
	}
	public static void main(String[] args) {
		RepeatedChar rc = new RepeatedChar();
		rc.yourName();

	}

}
