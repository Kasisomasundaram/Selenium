package week1.day1;

public class SumOfTen {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		for (int i =1 ; i <=10; i++)
		{
			sum =sum + i;
			
			//int k =i;
			//System.out.println(k);
			//int sum = k+i;
			
			System.out.println(sum);
			
		}


	}

}
