package week1.homework;

public class CountNonWhiteSpace {

	public static void main(String[] args) {
		String str = "Welcome to TestLeaf Software";
		String strTemp = str.replace(" ", "");
		int length = strTemp.length();

		System.out.println("Total number of character are: "+length);

	}

}


