package week1.homework;

public class OddIndexUpperCase {

	public static void main(String[] args) {
		String name = "sureshkumar";
		char ch;
		for (int i=0; i<name.length();i++)
		{
			ch =name.charAt(i);
			if (i%2 == 0) {
				System.out.print(Character.toUpperCase(ch));
			}else {
				System.out.print(Character.toLowerCase(ch));
			}

		}



	}

}
