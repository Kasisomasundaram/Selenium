package week1.homework;

public class ArmStrongNumber {

	public void strongNumber() {
		int number = 371, chk=0, a, temp;
		temp = number;

		while (number > 0)
		{
			a = number % 10;
			number = number / 10;
			chk = chk+(a*a*a);
		}

		if(temp == chk)
			System.out.println(temp + " is an Armstrong number.");
		else
			System.out.println(temp + " is not an Armstrong number.");
	}
	public static void main(String[] args) {

		ArmStrongNumber arm = new ArmStrongNumber();
		arm.strongNumber();
	}

}
