package week1.homework;

public class StringSplit {
	
	
	public void lastWord() {
		String str = "Standard Chartered Bank";
		String[] split = str.split(" ");
		//String fWord = split[0];
		String lastWord = split[split.length -1];
		System.out.print(lastWord);

	}

	public void allWord() {
		String str = "Standard Chartered Bank";
		String[] split = str.split(" ");
		for (String lword : split) {
			System.out.println(lword);
			
		}
	}
	
	public static void main(String[] args) {
		StringSplit strSplit = new StringSplit();
		strSplit.allWord();
		//strSplit.lastWord();
		
		
	}

}
