package week1.homework;

public class PrintNameStart {

	public void friendNames() {
		String [] name = {"Ajith", "Suresh" , "Rahul", "Arun", "Ashok"};
		for (int i =0; i<name.length;i++) {
			if(name[i].startsWith("A")) {
				System.out.println(name[i]);
			}

		}
	}
	public static void main(String[] args) {
		PrintNameStart str = new PrintNameStart();
		str.friendNames();

	}

}
