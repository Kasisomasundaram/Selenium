package week3.Day2.List;


import java.util.Map;
import java.util.TreeMap;

import org.openqa.selenium.interactions.Action;

public class MapCount {

	public static void main(String[] args) {

		String str = "Cheennaii";
		char[] ch = str.toCharArray();
		Map<Character,Integer> mapName = new TreeMap<>();
		for (char eachchar : ch) {			
			if (mapName.containsKey(eachchar)) {
				mapName.put(eachchar, mapName.get(eachchar)+1);
			}else {
				mapName.put(eachchar, 1);
				
			}
		}
		System.out.println(mapName);


	}

}

