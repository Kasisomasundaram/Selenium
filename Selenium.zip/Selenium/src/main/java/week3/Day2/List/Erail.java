package week3.Day2.List;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Erail {

	public void CollectionList() throws Exception  {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://erail.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("txtStationFrom").clear();
		driver.findElementById("txtStationFrom").sendKeys("MAS",Keys.TAB);
		driver.findElementById("txtStationTo").clear();
		driver.findElementById("txtStationTo").sendKeys("TVR",Keys.TAB);
		driver.findElementById("chkSelectDateOnly").click();
		driver.findElementById("buttonFromTo").click();
		driver.findElementById("chkSelectDateOnly").click();

		driver.findElementByXPath("//a[text() = 'Train']").click();
		List<WebElement> trainNumbers = driver.findElementsByXPath("//a[@title='Click on train number to View fare and schedule']");
		Set<String> str = new TreeSet<>();
		for(WebElement ele :trainNumbers) {
			String values = ele.getText();
			System.out.println(values);
			str.add(values);
		}
		System.out.println(str.size());
		System.out.println(trainNumbers.size());

		//		int trainOri = Integer.parseInt("values");
		//		int trainSort = Integer.parseInt("str");

		if(str.size() == trainNumbers.size()) {
			System.out.println("Total train counted");
		}

		driver.findElementByXPath("//a[@title = 'Click here to sort on Train Name']").click();
		Thread.sleep(2000);
		List<WebElement> trainName = driver.findElementsByXPath("//td[@style =';']/a");
		Set<String> name = new TreeSet<>();
		for (WebElement tName : trainName) {
			String values1 = tName.getText();
			System.out.println(tName);
			name.add(values1);
		}
		System.out.println(name);
		System.out.println(trainName);
		//		
		//		if(name.size() == trainName.size()) {
		//			System.out.println("Train name counted");
		//		}
	}

	public void ClassRoom() throws Exception {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver(); 
		driver.manage().window().maximize(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); 
		driver.get("https://erail.in/trains-between-stations/chennai-central-MAS/thiruvarur-jn-TVR"); 
		driver.findElementById("chkSelectDateOnly").click(); 

		//Train Number
		List<WebElement> beforSorting = driver.findElementsByXPath("//table[@class='DataTable TrainList']//tr/td[1]"); 
		List<Integer> ls = new ArrayList<>(); 
		for (WebElement eachTrain : beforSorting) { 
			ls.add(Integer.parseInt(eachTrain.getText())); 
		} 
		System.out.println(ls); 
		Collections.sort(ls); 
		System.out.println("Before Sorting: "+ls); 
		driver.findElementByXPath("//a[text()='Train']").click(); 
		Thread.sleep(3000); 

		//Train Name
		List<WebElement> sortedTrain = driver.findElementsByXPath("//table[@class='DataTable TrainList']//tr/td[1]"); 
		List<Integer> afterSorted = new ArrayList<>(); 
		for (WebElement eachSortedTrain : sortedTrain) { 
			afterSorted.add(Integer.parseInt(eachSortedTrain.getText())); 
		} 
		System.out.println("After Sorting: "+afterSorted); 
		for (int i = 0; i < ls.size(); i++) { 
			if (ls.get(i).equals(afterSorted.get(i)))  {
				System.out.println(ls.get(i)+"matched the value with : "+afterSorted.get(i));
			}
			}

	}
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			Erail rl = new Erail();
			rl.CollectionList();
		//	rl.ClassRoom();


	}

}
