package week3.HomeWork;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;


public class RemoveDuplicateName {

	public void DuplicateName() {

		String str[] = {"Siva", "Suresh", "Anand", "Siva", "Ramesh", "Ratheesh", "Balaji", "Anand"};
		List<String> name = new LinkedList<>();
		for (int i=0;i<str.length;i++) {
			if(!name.contains(str[i])) {
				name.add(str[i]);
			}
//				else {
//				System.out.println(str[i] +"   is duplicate");
//			}
			}
		Collections.sort(name);
		System.out.print(name);
	}

	public static void main(String[] args) {
		RemoveDuplicateName rdn = new RemoveDuplicateName();
		rdn.DuplicateName();	

	}

}
