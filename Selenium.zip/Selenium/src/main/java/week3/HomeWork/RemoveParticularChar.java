package week3.HomeWork;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RemoveParticularChar {

	public static void main(String[] args) {
		//input name in Array
		String str[] = {"Senthil", "Maddy" , "Daddy" , "Dinesh", "Siva"};
		
		//Creating a List
		List<String> lst = new ArrayList<>();
		
		//array Element added in List
		for (int i=0;i<str.length;i++) {
			lst.add(str[i]);
		}

		//checking the Particular char and remove from the list
		for (int j=0; j<lst.size();j++) {
			String rst = lst.get(j);
			if(rst.toLowerCase().contains("a")) {
				lst.remove(j);
				j=j-1;
			}
		}
		//Sort the resulted list
		Collections.sort(lst);
		for (String a : lst) {
			System.out.println(a);

		}


	}

}
