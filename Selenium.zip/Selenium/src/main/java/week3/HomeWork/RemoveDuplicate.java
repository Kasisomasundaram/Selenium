package week3.HomeWork;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicate {

	public static void main(String[] args) {

		String str = ("goodday");
		char[] ch = str.toCharArray();
		Set<Character> charSet = new LinkedHashSet<>();
		for (int i=0;i<ch.length; i++) {
			charSet.add(ch[i]);
		}
		System.out.println("Set :"+str);
		List<Character> lnew = new ArrayList<>();
		lnew.addAll(charSet);
		for(int j=0;j<lnew.size();j++) {
			Character a = lnew.get(j);
			System.out.print(a);
		}

	}		

}


