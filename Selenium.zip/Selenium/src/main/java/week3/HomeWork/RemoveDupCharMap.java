package week3.HomeWork;

import java.util.Map;
import java.util.TreeMap;

public class RemoveDupCharMap {

	public void DuplicateMap() {

		String str = "anand";
		char[] ch = str.toCharArray();
		Map<Character, Integer> name = new TreeMap<>();
		for (char c : ch) {
			if(name.containsKey(c)) {
				name.remove(c);
				System.out.println(c);
			}
			name.put(c, 1);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoveDupCharMap dm = new RemoveDupCharMap();
		dm.DuplicateMap();

	}

}
