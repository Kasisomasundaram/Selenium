package week3.Day1;

public class Samsung extends Andorid{
	
	public void Features() {
		System.out.println("Override New Features Added");
	}

}
