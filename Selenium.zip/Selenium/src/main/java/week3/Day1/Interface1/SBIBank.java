package week3.Day1.Interface1;

public class SBIBank implements RBI,CIBIL {

	@Override
	public void Aadhar() {

		System.out.println("Print Valid Aadhar Number SBI");

	}

	@Override
	public void PanCard() {

		System.out.println("Print valid PanCard SBI");

	}

	@Override
	public void Transaction() {

		System.out.println("Number of Transactions SBI   "+number);

	}

}
