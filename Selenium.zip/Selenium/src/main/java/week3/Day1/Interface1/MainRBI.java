package week3.Day1.Interface1;

public class MainRBI {

	public static void main(String[] args) {
		
		AxisBank objAxis = new AxisBank();
		objAxis.Aadhar();
		objAxis.PanCard();
		objAxis.Transaction();
			
		SBIBank objSBI = new SBIBank();
		objSBI.Aadhar();
		objSBI.PanCard();
		objSBI.Transaction();

	}

}
