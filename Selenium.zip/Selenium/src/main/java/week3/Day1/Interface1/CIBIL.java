package week3.Day1.Interface1;

public interface CIBIL {
	int num = 5;
}
