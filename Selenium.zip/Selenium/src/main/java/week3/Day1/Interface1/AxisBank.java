package week3.Day1.Interface1;

public class AxisBank extends SBIBank implements RBI,CIBIL {

	@Override
	public void Aadhar() {

		System.out.println("Print Valid Aadhar Number AXIS");

	}

	@Override
	public void PanCard() {

		System.out.println("Print valid PanCard AXIS");

	}

	@Override
	public void Transaction() {

		System.out.println("Number of Transactions AXIS   "+num);

	}



}
