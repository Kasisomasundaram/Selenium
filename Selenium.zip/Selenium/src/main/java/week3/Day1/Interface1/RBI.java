package week3.Day1.Interface1;


 
 
public interface RBI {
	int number = 10;
	
	public void Aadhar();
	
	public void PanCard();
	
	public void Transaction();
	

}
