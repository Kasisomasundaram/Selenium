package week3.Day1;

public class MainFunction {

	public static void main(String[] args) {
		
		Mobile objMobile = new Mobile();
		objMobile.dialCall();
		objMobile.takePhoto();

		Andorid objAndorid = new Andorid();
		objAndorid.dialCall();
		objAndorid.Features();
		objAndorid.takePhoto();
		
		Samsung objSamsung = new Samsung();
		objSamsung.Features();
		
		Nokia objNokia = new Nokia();
		objNokia.Features();
		
		XE objXE = new XE();
		objXE.appleFeatures();
		
		XR objXR = new XR();
		objXR.appleFeatures();

	}

}
