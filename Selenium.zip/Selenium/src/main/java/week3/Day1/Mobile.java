package week3.Day1;

public class Mobile {

	public void takePhoto() {
		System.out.println("Taking Picture");
	}
	
	public void dialCall() {
		System.out.println("Dialing a call");
	}
	
}
