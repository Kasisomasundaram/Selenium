package week3.Day1;

public class Nokia extends Andorid{
	
	public void Features() {
		System.out.println("Nokia override New Features Added");
	}

}
