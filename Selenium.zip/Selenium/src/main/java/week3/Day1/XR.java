package week3.Day1;

public class XR extends Apple{

	public void appleFeatures() {
		System.out.println(" OS Apple Featurs added");
	}

}
