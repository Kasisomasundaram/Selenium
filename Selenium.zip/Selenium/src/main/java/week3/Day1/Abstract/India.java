package week3.Day1.Abstract;

public class India implements ICC {

	public void Matches() {
	}

	public void Team() {
	}

	@Override
	public void Season() {
		// TODO Auto-generated method stub
		
	}

	

}
