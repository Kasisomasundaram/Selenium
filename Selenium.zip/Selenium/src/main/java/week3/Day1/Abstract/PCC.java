package week3.Day1.Abstract;

public class PCC implements ICC {

	@Override
	public void Matches() {
		
		System.out.println("Matches");
		
	}

	@Override
	public void Team() {
		System.out.println("Teams");
		
	}

	@Override
	public void Season() {
		System.out.println("Season");
		
	}

}
