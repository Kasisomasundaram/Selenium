package week3.Day1.Abstract;

public interface ICC {

	int num1 =15;
	final int num2 =10;
	
	public void Matches();

	public void Team();

	public void Season();

}
