package week3.Day1.Abstract;

public class IPL extends BCCI {

	
	@Override
	public void Season() {
		
		System.out.println("When Season match will start  "+num1);
		
	}

}
