package week3.Day1.Abstract;

public class MainClass {

	public static void main(String[] args) {
		
		IPL objIPL = new IPL();
		objIPL.Matches();
		objIPL.Season();
		objIPL.Team();
		
		PCC objPCC= new PCC();
		objPCC.Matches();
		objPCC.Season();
		objPCC.Team();

	}

}
