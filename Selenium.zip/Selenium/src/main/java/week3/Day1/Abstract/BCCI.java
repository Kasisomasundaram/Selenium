package week3.Day1.Abstract;

public abstract class BCCI implements ICC{
    
	//private int num1=10;
	@Override
	public void Matches() {
		
		System.out.println("No of Matches "+num1);
		
	}

	@Override
	public void Team() {
		
		System.out.println("No of Teams formed "+num2);
		
	}

	
	
}
