package week3.Day1;

public class Andorid extends Mobile{
	
	public void Features() {
		System.out.println("New Features Added");
	}

}
