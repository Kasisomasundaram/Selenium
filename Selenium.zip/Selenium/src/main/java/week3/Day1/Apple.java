package week3.Day1;

public class Apple extends Mobile{
	
	public void appleFeatures() {
		System.out.println("Apple Featurs added");
	}

}
