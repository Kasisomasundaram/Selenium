package Leads;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class MergeLead {
@Test
	public void MergeLeadTest() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByXPath("//a[text()='Leads']").click();
		driver.findElementByXPath("//a[text()='Merge Leads']").click();
		
		//From Lead
		driver.findElementByXPath("//img[@alt='Lookup']").click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> lst = new ArrayList<>();
		lst.addAll(allWindows);
		driver.switchTo().window(lst.get(1));
		String childWindow = driver.getTitle();
		System.out.println(childWindow);
		driver.switchTo().window(lst.get(1));
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("10062");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.switchTo().window(lst.get(0));
		driver.switchTo().defaultContent();
		
		//To Lead
		driver.findElementByXPath("(//img[@alt='Lookup'])[2]").click();
		Set<String> cAllWindows = driver.getWindowHandles();
		List<String> cLst = new ArrayList<>();
		cLst.addAll(cAllWindows);
		/*String titleBrowser = driver.getTitle();
		System.out.println(titleBrowser);*/
		driver.switchTo().window(cLst.get(1));
		String browTitle = driver.getTitle();
		System.out.println(browTitle);
		driver.findElementByXPath("(//label[contains(text(),'Lead ID:')]/following::input)[1]").sendKeys("10063");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.switchTo().window(lst.get(0));
		
		driver.findElementByLinkText("Merge").click();
		
		driver.switchTo().alert().accept();
		
		driver.findElementByLinkText("Find Leads").click();
		
		driver.findElementByXPath("((//div[@class='x-form-element'])/input)[13]").sendKeys("10062");
		
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(3000);
		 WebElement strText = driver.findElementByXPath("//div[@class='x-paging-info']");
		 String text = strText.getText();		 
		 System.out.println(text);
		 driver.close();
		}
	
	public static void main(String[] args) throws InterruptedException {
		MergeLead ml = new MergeLead();
		ml.MergeLeadTest();

	}

}
