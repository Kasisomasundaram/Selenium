package Leads;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DeleteLead {
@Test
	public void DeleteLEadTest() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		Thread.sleep(2000);
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//span[@class ='x-tab-strip-text '])[2]").click();
		//driver.findElementByXPath("(//input[@name = 'phoneAreaCode'])[2]").sendKeys("91");
		driver.findElementByXPath("(//input[@name = 'phoneNumber'])[1]").sendKeys("9176619388");
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		WebElement leadID = driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		String text = leadID.getText();
		System.out.println("First Lead ID "+text);
		String replaceText = text.replaceAll("[^0-9]", "");
		System.out.println(replaceText);
		
		driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.findElementByLinkText("Delete").click();
		driver.findElementByXPath("//a[@href = '/crmsfa/control/findLeads']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//label[contains(text(), 'Lead ID')]/following::input)[1]").sendKeys(replaceText);
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		String errorMessage = driver.findElementByXPath("//div[@class = 'x-paging-info']").getText();
		System.out.println("The Error Message  "+errorMessage);
		driver.close();
		
		
	}

}
