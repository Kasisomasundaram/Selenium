package Leads;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Google {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver(options);
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//driver.findElementByXPath("//input[@title ='Search']").sendKeys("Laser",Keys.TAB);
		
		driver.findElementById("email").sendKeys("e.siva.raj@gmail.com");
		driver.findElementById("pass").sendKeys("Welcome2india!");
		driver.findElementByName("login").click();
		Thread.sleep(3000);
		driver.findElementByXPath("//div[@aria-label = 'Account'][i]").click();
		driver.findElementByXPath("//span[text()='Log Out']").click();
	//	driver.quit();
	}

}
