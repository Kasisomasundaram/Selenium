package Leads;

import java.io.IOException;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {



	public static void main(String[] args) throws IOException {
		XSSFWorkbook wBook = new XSSFWorkbook("./data/Testing.xlsx");
		XSSFSheet sheet = wBook.getSheetAt(0);	
		//String [][] data = new String [5][5];
		XSSFRow row = sheet.getRow(2);
		XSSFCell cell = row.getCell(3);
		System.out.println(cell);
	}

}
