package JavaProgram;

public class SwapTwoNumbers {

	public static void main(String[] args) {
		
		int x = 10;
		int y = 5;
		
		//Before Swaping X and Y Values
		
		System.out.println("Before Swaping:" + " X = " + x + ", Y = " + y);
		
		x = x+y;
		y = x-y;
		x = x-y;
		
		//x = x^y;
		//y = x^y;
		//x= x^y;
		
		//After Swaping X and Y values
		
		System.out.println("After Swaping:" + " X = " + x + ", Y = " + y);
		

	}

}
