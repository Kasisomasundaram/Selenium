package JavaProgram;

public class NextChar {

	public static void main(String[] args) {

		String str = "23B4EF0";
		char[] ch = str.toCharArray();
		for (char c : ch) {
			int asc = ((int)c)+1;
			System.out.print((char)asc);
		}

	}

}
