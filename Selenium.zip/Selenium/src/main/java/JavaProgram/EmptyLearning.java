package JavaProgram;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.cli.Main;

public class EmptyLearning {
	
	public void Learning() {
	
	System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	driver.navigate().to("");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	
	Select dropdown = new Select (driver.findElementById(""));
	List<WebElement> options = dropdown.getOptions();
	System.out.println(options.size());
	
	}
	
	public void Occurance() {
		String str = "welcome to automation";
		int count =0;		
		char c = str.charAt(0);
		for (int i = 0; i < str.length(); i++) {
			if (c == str.charAt(i)) {
				count ++;
			}
			
		}
		System.out.println(c + " occurs " +count+ " times in " +str);
			
	}
	public static void main(String[] args) {
		EmptyLearning emp = new EmptyLearning();
		emp.Occurance();
	}
}


