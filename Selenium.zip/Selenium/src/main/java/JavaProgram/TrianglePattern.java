package JavaProgram;

public class TrianglePattern {

	public void fullTraingle() {
		int rows = 5, k = 0;

		for(int i = 1; i <= rows; i++, k=0) {
			for(int j = 1; j <= rows - i; j++) {
				System.out.print("  ");
			}

			while(k != 2 * i - 1) {
				System.out.print("* ");
				k++;
			}

			System.out.println();
		}

	}

	public void halfTriangleNumber() {

		int row = 5;
		for (int i = 1; i <=row; i++) {
			for (int j = 1; j <=i; j++) {
				System.out.print(j+ "");

			}
			System.out.println();
		}

	}

	public void halfTriangleStar() {

		int row = 5;
		for (int i = 1; i <=row; i++) {
			for (int j = 1; j <=i; j++) {
				System.out.print("*");

			}
			System.out.println();
		}

	}

	public static void main(String[] args) {
	TrianglePattern tp = new TrianglePattern();
	//tp.halfTriangleNumber();
	tp.fullTraingle();
	//tp.halfTriangleStar();

}
}
