package ParaDataProvider;



import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DuplicateLead extends BaseUtils {
	
	@BeforeTest
	public void getData1() {
		ExcelName ="DuplicateLead";	

	}	
	@Test(dataProvider ="fetchData")
	public void DuplicateLeadTest(String eMail) throws InterruptedException {
		
		
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//span[@class ='x-tab-strip-text '])[3]").click();
		driver.findElementByXPath("(//input[@name='emailAddress'])[1]").sendKeys(eMail);
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		WebElement emailID = driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a");
		String text = emailID.getText();
		System.out.println(text);
		driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.findElementByXPath("//a[text()='Duplicate Lead']").click();
		Thread.sleep(2000);
		String DuplicteTitle = driver.getTitle();
		System.out.println(DuplicteTitle);
		WebElement firstName = driver.findElementById("createLeadForm_firstName");
		String name = firstName.getText();
		System.out.println(name);		
		driver.findElementByXPath("//a[text()='Create Lead']").click();
		if(text.contains(name)) {
			System.out.println("Equal name "+text);
		}else {
			System.out.println("Name not equal  "+name);
		
		}
		
		
	}

}
