package ParaDataProvider;

import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DeleteLead extends BaseUtils {
	
	@BeforeTest
	public void getData1() {
		ExcelName ="DeleteLead";	

	}
	
@Test(dataProvider = "fetchData")
	public void DeleteLEadTest(String pNum) throws InterruptedException {
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//span[@class ='x-tab-strip-text '])[2]").click();
		//driver.findElementByXPath("(//input[@name = 'phoneAreaCode'])[2]").sendKeys("91");
		driver.findElementByXPath("(//input[@name = 'phoneNumber'])[1]").sendKeys(pNum);
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		WebElement leadID = driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a");
		String text = leadID.getText();
		System.out.println("First Lead ID "+text);
		String replaceText = text.replaceAll("[^0-9]", "");
		System.out.println(replaceText);
		
		driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.findElementByLinkText("Delete").click();
		driver.findElementByXPath("//a[@href = '/crmsfa/control/findLeads']").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//label[contains(text(), 'Lead ID')]/following::input)[1]").sendKeys(replaceText);
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		String errorMessage = driver.findElementByXPath("//div[@class = 'x-paging-info']").getText();
		System.out.println("The Error Message  "+errorMessage);
		
		
		
	}

}
