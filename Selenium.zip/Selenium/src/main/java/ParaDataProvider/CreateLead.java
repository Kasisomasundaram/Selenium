package ParaDataProvider;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;


import org.testng.annotations.Test;

public class CreateLead extends BaseUtils {
	
	@BeforeTest
	public void getData1() {
		ExcelName ="CreateLead";	
		
	}
	
	@Test (dataProvider = "fetchData" )
	public void  CreateLeadTest(String cname, String fname, String lname, String pNum, String eMail) throws InterruptedException {
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys(cname);
		driver.findElementById("createLeadForm_firstName").sendKeys(fname);
		driver.findElementById("createLeadForm_lastName").sendKeys(lname);
		//Source DropDown
		WebElement srcSource = driver.findElementById("createLeadForm_dataSourceId");
		Select sel = new Select(srcSource);
		sel.selectByIndex(3);
		//Marketing Campaign
		WebElement srcMarket = driver.findElementById("createLeadForm_marketingCampaignId");
		Select dropdown = new Select (srcMarket);
		dropdown.selectByValue("CATRQ_CARNDRIVER");
		
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys(pNum);
		driver.findElementById("createLeadForm_primaryEmail").sendKeys(eMail);
		//click the Create Lead button
		driver.findElementByClassName("smallSubmit").click();
		
		String leadID = driver.findElementById("viewLead_companyName_sp").getText();
		System.out.println("The Lead ID  "+leadID);
		
		}
	
	
	/*	@DataProvider()
	    String [][] data = new String [2][3];
		data [0][0] = "CTS";
		data [0][1] = "Siva";
		data [0][2] = "E";
		
		data [1][0] = "TCS";
		data [1][1] = "Sridhar";
		data [1][2] = "E";
		return data;
		*/
				
	}

