package ParaDataProvider;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class EditLead extends BaseUtils {

	@BeforeTest
	public void getData1() {
		ExcelName ="EditLead";	

	}

	@Test (dataProvider = "fetchData") //dependsOnMethods = "Attributes.CreateLead.CreateLeadTest"
	public void EditLeadTest(String fname, String cname) throws InterruptedException {


		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("(//input[@name='firstName'])[3]").sendKeys(fname);
		driver.findElementByXPath("//button[contains(text(),'Find Leads')]").click();
		Thread.sleep(3000);
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-firstName']/a").click();
		String titleViewLead = driver.getTitle();
		System.out.println(titleViewLead);
		driver.findElementByXPath("//a[contains(text(),'Edit')]").click();
		driver.findElementByXPath("(//input[@name='companyName'])[2]").clear();
		driver.findElementByXPath("(//input[@name='companyName'])[2]").sendKeys(cname);
		driver.findElementByName("submitButton").click();
		String textTitle = driver.findElementById("viewLead_companyName_sp").getText();
		System.out.println(textTitle);



	}

}
