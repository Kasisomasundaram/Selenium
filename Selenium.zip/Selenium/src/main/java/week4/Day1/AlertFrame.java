package week4.Day1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertFrame {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.switchTo().frame("iframeResult");
		driver.findElementByXPath("//button[text() = 'Try it']").click();
		Alert myAlert = driver.switchTo().alert();
		String alertText = myAlert.getText();
		System.out.println(alertText);		
		driver.switchTo().alert().sendKeys("Sivaraj");
		myAlert.accept();
		String myText = driver.findElementById("demo").getText();
		if(myText.contains("Sivaraj"))
		{
			System.out.println("Text verified :"+myText);
		}else {
			System.out.println("Text mismatching");
		}
		
	}
	
	
}
