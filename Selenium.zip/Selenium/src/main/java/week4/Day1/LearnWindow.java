package week4.Day1;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class LearnWindow {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
//		String window = driver.getWindowHandle();
//		System.out.println(window);
		driver.findElementByXPath("//a[text()='Contact Us']").click();
		Set<String> allWindows = driver.getWindowHandles();

		List<String> lst = new ArrayList<>();
		lst.addAll(allWindows);
		driver.switchTo().window(lst.get(1));
		driver.manage().window().maximize();
		String ChildWindowTitle = driver.getTitle();
		System.out.println(ChildWindowTitle);
		driver.switchTo().window(lst.get(0));
		driver.close();
		Thread.sleep(3000);
		driver.switchTo().window(lst.get(1));
		driver.close();
		

	}

}
