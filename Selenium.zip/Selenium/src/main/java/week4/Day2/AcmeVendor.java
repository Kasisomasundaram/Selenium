package week4.Day2;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AcmeVendor {

	public void ACME() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://acme-test.uipath.com/account/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//a[text()='Register']").click();
		driver.findElementById("emailNew").sendKeys("abcfas1123as1231d@gmail.com");
		driver.findElementById("passwordNew").sendKeys("Welcome1!");
		driver.findElementById("confirmNew").sendKeys("Welcome1!");
		driver.findElementById("checkTerms").click();
		driver.findElementById("buttonRegister").click();
		WebElement userProducts = driver.findElementByXPath("//i[@class='fa fa-user']");
		Actions builder = new Actions(driver);
		builder.moveToElement(userProducts).build().perform();
		driver.findElementByXPath("//a[text()='Reset test data']").click();
		driver.findElementById("buttonRTD").click();	
		Thread.sleep(3000);
		driver.switchTo().alert().accept();		
	}

	public void Vendor() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://acme-test.uipath.com/account/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("email").sendKeys("e.siva.raj@gmail.com");
		driver.findElementById("password").sendKeys("Welcome");
		driver.findElementById("buttonLogin").click();
		WebElement vendors = driver.findElementByXPath("//i[@class='fa fa-truck']");
		Actions builder = new Actions(driver);
		builder.moveToElement(vendors).build().perform();
		driver.findElementByXPath("//a[text()='Search for Vendor']").click();
		driver.findElementById("vendorTaxID").sendKeys("DE767565");
		driver.findElementById("buttonSearch").click();
		WebElement vendorTitle = driver.findElementByXPath("//table[@class='table']//tr[2]/td");
		String Title = vendorTitle.getText();
		System.out.println("The Title is "+Title);

	}

	public void Sample() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://acme-test.uipath.com/account/login");
		driver.manage().window().maximize();
		//String handle = driver.getWindowHandle();
		Set<String> handle = driver.getWindowHandles();
		for (String h : driver.getWindowHandles()) {
			driver.switchTo().window(h);
			
		}
		
			
		
	}

	public static void main(String[] args) throws InterruptedException {
		AcmeVendor ac= new AcmeVendor();
		//ac.ACME();
		ac.Vendor();

	}

}
