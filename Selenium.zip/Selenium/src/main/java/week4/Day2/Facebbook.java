package week4.Day2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Facebbook {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeOptions op = new ChromeOptions();
		op.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(op);
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("email").sendKeys("e.siva.raj@gmail.com");
		driver.findElementById("pass").sendKeys("Welcome2india!");
		driver.findElementByXPath("//input[@value='Log In']").click();
		Thread.sleep(5000);
		
		driver.findElementByClassName("_1frb").sendKeys("TestLeaf");
		driver.findElementByXPath("//button[@data-testid ='facebar_search_button']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[text()='Places'])[1]").click();
		Thread.sleep(5000);
		WebElement verifyTestLeaf = driver.findElementByLinkText("TestLeaf");
		String text = verifyTestLeaf.getText();
		if (text.contains("TestLeaf")) {
			System.out.println("Name Verified  "+text);
		}else {
			System.out.println("Name not verified");
		}
		WebElement likeText = driver.findElementByXPath("(//button[@type='submit'])[17]");
		String textB = likeText.getText();
		System.out.println("The button text  "+textB);
		if (textB.contains("Liked")) {
			System.out.println("alread Liked");
			
		}else {
			likeText.click();
		}
		verifyTestLeaf.click();
		String browserTitle = driver.getTitle();
		System.out.println("The Browser Title is " +browserTitle);
		Thread.sleep(3000);
		WebElement totalLikedText = driver.findElementByXPath("//img[@alt='Highlights info row image']/following::div[2]");
		String textG = totalLikedText.getText();
		System.out.println(textG);
		
		String likeCount= textG.replaceAll("[^0-9]", "");
		System.out.println(likeCount);
		

	}

}
