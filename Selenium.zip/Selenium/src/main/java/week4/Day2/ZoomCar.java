package week4.Day2;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ZoomCar {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		//Get Current Date
		Date date = new Date();
		DateFormat sdf = new SimpleDateFormat("dd");
		String cDateStr = sdf.format(date);
		//Convert Current date to Integer to add 1 (Tomorrow Date)
		int cDateInt = Integer.parseInt(cDateStr)+1;
		//Convert tomorrow date to String
		String addDate = Integer.toString(cDateInt);
		
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.zoomcar.com/chennai/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementByXPath("//a[@title='Start your wonderful journey']").click();
		driver.findElementByXPath("(//div[@class='component-popular-locations'])/div[5]").click();
		driver.findElementByXPath("//button[@class='proceed']").click();
		
		//Select tomorrow date and Click Next & Done
		driver.findElementByXPath("//div[contains(text(),'"+addDate+"')]").click();
		driver.findElementByXPath("//button[@class='proceed']").click();
		driver.findElementByXPath("//button[@class='proceed']").click();
		Thread.sleep(3000);
		
		List<WebElement> carPrice = driver.findElementsByXPath("//div[@class='price']");
		List<WebElement> carDetails = driver.findElementsByXPath("//div[@class='details']/h3");
		
		System.out.println("Total number of Cars "+carPrice.size());
		
		List<Integer> listCar = new ArrayList<>();
		Map<Integer,String> mpCar = new TreeMap<>();
		
		for (int i=0;i<carPrice.size();i++) {
			String carText = carPrice.get(i).getText();
			String carPriceOnly = carText.replaceAll("[^0-9]", "");
//			System.out.print(carPriceOnly);
			String nameText = carDetails.get(i).getText();
			listCar.add(Integer.parseInt(carPriceOnly));
			mpCar.put(Integer.parseInt(carPriceOnly), nameText);			
		}
		Collections.sort(listCar);
		Integer highestValue = listCar.get(listCar.size()-1);
		System.out.println("Maximum Price :"+highestValue);
		String carName = mpCar.get(listCar.get(listCar.size()-1));
		System.out.println("Car Name: "+carName);
		
		driver.findElementByXPath("((//h3[text()= '"+carName+"']/parent::div)/following::div//button)[1]").click();
		
		
		
		
		
		
		


	}

}
