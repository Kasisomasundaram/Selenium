package Attributes;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DuplicateLead {
@Test
	public void DuplicateLeadTest() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		Thread.sleep(2000);
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Leads").click();
		driver.findElementByLinkText("Find Leads").click();
		Thread.sleep(2000);
		driver.findElementByXPath("(//span[@class ='x-tab-strip-text '])[3]").click();
		driver.findElementByXPath("(//input[@name='emailAddress'])[1]").sendKeys("e.siva.raj@gmail.com");
		Thread.sleep(2000);
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(2000);
		WebElement emailID = driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a");
		String text = emailID.getText();
		System.out.println(text);
		driver.findElementByXPath("(//div[@class ='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.findElementByXPath("//a[text()='Duplicate Lead']").click();
		Thread.sleep(2000);
		String DuplicteTitle = driver.getTitle();
		System.out.println(DuplicteTitle);
		WebElement firstName = driver.findElementById("createLeadForm_firstName");
		String name = firstName.getText();
		System.out.println(name);		
		driver.findElementByXPath("//a[text()='Create Lead']").click();
		if(text.contains(name)) {
			System.out.println("Equal name "+text);
		}else {
			System.out.println("Name not equal  "+name);
		
		}
		
		
	}

}
