package week2.day2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTablesOne {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/table.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		List<WebElement> rows = driver.findElementsByXPath("//table/tbody/tr[*]/td/parent::tr");
		System.out.println("No of rows  "+rows.size());

		List<WebElement> columns = driver.findElementsByXPath("//table/tbody/tr/th");
		System.out.println("No of columns "+columns.size());

		WebElement percentage = driver.findElementByXPath("(//font[contains(text(),'Learn')])[3]/following::td[1]");
		System.out.println("Percentate value  "+percentage.getText());

		WebElement perct1 = driver.findElementByXPath("//font[contains(text(),'Locators')]/following::font");	
		String p1 = perct1.getText();
		p1 = p1.substring(0,3);

		WebElement perct2 = driver.findElementByXPath("//font[contains(text(), 'Elements')]/following::font");
		String p2 = perct2.getText();
		p2 = p2.substring(0, 2);

		WebElement percet3 = driver.findElementByXPath("//font[contains(text(),'Exceptions')]/following::font");
		String p3 = percet3.getText();
		p3 = p3.substring(0, 2);

		System.out.println(p1 +" "+ p2 +" " +p3);

		int num1 = Integer.parseInt(p1);
		int num2 = Integer.parseInt(p2);
		int num3 = Integer.parseInt(p3);

		if (num1 <num2 && num1 < num3) {
			System.out.println("Lesser number n1 is  "+num1);
		}else if (num2 < num3 && num2 < num1) {
			System.out.println("Lesser number n2 is  "+ num2);
		}else {
			System.out.println("Lesser number n3 is   "+num3);
		}



	}

}
