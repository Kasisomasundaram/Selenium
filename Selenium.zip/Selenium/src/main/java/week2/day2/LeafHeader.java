package week2.day2;


import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LeafHeader{

	public void AllTableData() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/table.html");
		driver.manage().window().maximize();
		for(WebElement tValues:driver.findElementsByTagName("tr"))
		{
			System.out.println(tValues.getText());
			
		}
		driver.close();
	}
	public void TableHeader() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/table.html");
		driver.manage().window().maximize();
		for(WebElement tHeader:driver.findElementsByTagName("th"))
		{
			System.out.println(tHeader.getText());
			
		}
		driver.close();
	}
	public void TableHeaderDiff() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/table.html");
		driver.manage().window().maximize();
		List<WebElement> allHeaders = driver.findElementsByXPath("//table/tbody/tr/th");
		allHeaders.size();
		for (int i=0;i<allHeaders.size();i++) {
			String headerTitle = allHeaders.get(i).getText();
			System.out.println(headerTitle);
		}
	}
	public static void main(String[] args) {
		LeafHeader plg = new LeafHeader();
		//plg.TableHeader();
		plg.AllTableData();
		//plg.TableHeaderDiff();


	}

}
