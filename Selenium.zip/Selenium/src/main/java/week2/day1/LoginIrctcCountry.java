package week2.day1;


import java.util.List;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginIrctcCountry {
	static int i =0;
	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement country = driver.findElementById("userRegistrationForm:countries");
		//create an object using Select Class
		Select sel = new Select(country);
		//Get collection of WebElement and store in the list
		List<WebElement> options = sel.getOptions();
		//iteration through each Web Element based on condection
		for (WebElement eachoption:options) {
			if (eachoption.getText().startsWith("E")) {
				i++;
				if(i==2) {
					System.out.println(eachoption.getText());
					eachoption.click();
					break;
					
				}
			}
		}
		


		//		WebElement sel = driver.findElementByXPath("//select [@class ='form-control ng-valid ng-dirty ng-touched']");
		//		sel.click();
		//		Select sc = new Select (sel);
		//		sc.selectByVisibleText("Egypt");

	}

}
