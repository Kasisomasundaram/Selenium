package week2.day1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginIrctc {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.irctc.co.in/eticketing/userSignUp.jsf");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//Individual Registration
		driver.findElementById("userRegistrationForm:userName").sendKeys("esivaraj1982");
		driver.findElementById("userRegistrationForm:password").sendKeys("sivadhya");
		driver.findElementById("userRegistrationForm:confpasword").sendKeys("sivadhya");
		
		WebElement securityQuestion = driver.findElementById("userRegistrationForm:securityQ");
		Select dropDown1 = new Select(securityQuestion);	
		dropDown1.selectByIndex(2);
		driver.findElementById("userRegistrationForm:securityAnswer").sendKeys("Rotary");

		//Personal Details
		driver.findElementById("userRegistrationForm:firstName").sendKeys("Sivaraj");
		driver.findElementById("userRegistrationForm:gender").click();
		driver.findElementById("userRegistrationForm:maritalStatus:0").click();
		
		//Date Of Birth  - Date
		WebElement dobDate = driver.findElementById("userRegistrationForm:dobDay");
		Select dropDown2 = new Select(dobDate);
		List<WebElement> date1 = dropDown2.getOptions();
		dropDown2.selectByIndex(date1.size()-1);
		
		//Date of Birth - Month
		WebElement dobMonth = driver.findElementById("userRegistrationForm:dobMonth");
		Select dropDown3 = new Select(dobMonth);
		dropDown3.selectByValue("10");
		
		//Date of Birth - Year
		WebElement dobYear = driver.findElementById("userRegistrationForm:dateOfBirth");
		Select dropDown4 = new Select(dobYear);
		dropDown4.selectByValue("1982");
		
		//Select Occupation
		WebElement occupation = driver.findElementById("userRegistrationForm:occupation");
		Select dropDown5 = new Select(occupation);
		dropDown5.selectByVisibleText("Professional");
		
		//Enter Aadhaar Number
		driver.findElementById("userRegistrationForm:uidno").sendKeys("89312246273462");
		
		//Enter PAN Card
		driver.findElementById("userRegistrationForm:idno").sendKeys("AAOPE3967G");
		
		//Select country Drop Down
		WebElement countries = driver.findElementById("userRegistrationForm:countries");
		Select dropDown6 = new Select(countries);
		dropDown6.selectByValue("94");
		
		//Enter Email Address
		driver.findElementById("userRegistrationForm:email").sendKeys("e.siva.raj@gmail.com");
		
		//Enter ISD Code
		//driver.findElementById("userRegistrationForm:isdCode").sendKeys("91");
		
		//Enter ISD Number
		driver.findElementById("userRegistrationForm:mobile").sendKeys("9176619388");
		
		//Select the Nationality
		WebElement nationality = driver.findElementById("userRegistrationForm:nationalityId");
		Select dropDown7 = new Select(nationality);
		dropDown7.selectByVisibleText("India");
		
		//Residential Address Section
		//Enter the Flat/Block Number
		driver.findElementById("userRegistrationForm:address").sendKeys("VM FLAT,KATTUPAKKAM");
		
		//Enter ZipCode
		driver.findElementById("userRegistrationForm:pincode").sendKeys("600056",Keys.TAB);
		Thread.sleep(4000);
		
		//Select the City/Town Name
		WebElement cityTown = driver.findElementByXPath("//select[@id = 'userRegistrationForm:cityName']");
		Select dropDown8 = new Select(cityTown);
		dropDown8.selectByValue("Tiruvallur");
		Thread.sleep(4000);
		
		//Select the Post Office
		WebElement postOffice = driver.findElementByXPath("//select[@id ='userRegistrationForm:postofficeName']");
		Select dropDown9 = new Select(postOffice);
		dropDown9.selectByVisibleText("Kattupakkam B.O");
		
		//Enter the Phone Number
		driver.findElementByXPath("//input[@id = 'userRegistrationForm:landline']").sendKeys("044234567");
				
		
	}

}
