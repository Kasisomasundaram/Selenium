package week2.day1;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Login {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys("IBM");
		driver.findElementById("createLeadForm_firstName").sendKeys("Sivaraj");
		driver.findElementById("createLeadForm_lastName").sendKeys("Elangovan");
		driver.findElementByClassName("smallSubmit").click();
		//To get the title of the browser
		String title = driver.getTitle();
		System.out.println(title);
		driver.findElementByLinkText("Edit").click();
		//Select Drop Down Element1
		WebElement industry = driver.findElementById("updateLeadForm_industryEnumId");
		Select dropDown1 = new Select (industry);
		dropDown1.selectByVisibleText("Computer Software");
		//Select Drop Down Element2
		WebElement ownership = driver.findElementById("updateLeadForm_ownershipEnumId");
		Select dropDown2 = new Select (ownership);
		List<WebElement> options = dropDown2.getOptions();
		System.out.println(options.size());
		dropDown2.selectByIndex(options.size()- 1);
		
		
		


	}

}
