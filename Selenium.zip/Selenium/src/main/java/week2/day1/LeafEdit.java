package week2.day1;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LeafEdit {
	
	public void Edit() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/Edit.html");
		driver.manage().window().maximize();
		driver.findElementById("email").sendKeys("e.siva.raj@gmail.com");
		driver.findElementByXPath("//input[@value = 'Append ']").sendKeys("JOINING");
		String text = driver.findElementByXPath("//input[@value = 'TestLeaf']").getAttribute("Value");
		System.out.println("The Entered text is :"+text);
		driver.findElementByXPath("(//input[@name = 'username'])[2]").clear();
		driver.close();
	}
	
	public void Button() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://www.leafground.com/pages/Button.html");
		driver.manage().window().maximize();
		//Go to Home Page
		//driver.findElementById("home").click();
		
		//Find the position of the button  X,Y
		Point location = driver.findElementById("position").getLocation();
		System.out.println("X position :"+location.getX());
		System.out.println("X position :"+location.getY());
		
		//Find Button Color
		String colorValue = driver.findElementById("color").getCssValue("background-color");
		System.out.println("The Button color "+colorValue);
		
		//Find the Height and Width
		WebElement HeightWidth = driver.findElementById("size");
		int height = HeightWidth.getSize().getHeight();
		System.out.println("The button height is "+height);
		int width = HeightWidth.getSize().getWidth();
		System.out.println("the button width is "+width);
	}

	public static void main(String[] args) {
		LeafEdit plg = new LeafEdit();
		//plg.Edit();
		plg.Button();
		
		
		//		String clr = driver.findElementById("color").getCssValue("background-color");
		//		System.out.println("The Button color is "+clr);
	}

}
