package Annotations;



import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class CreateLead extends BaseUtils {

	@Test 
	public void  CreateLeadTest() throws InterruptedException {
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByLinkText("Create Lead").click();
		driver.findElementById("createLeadForm_companyName").sendKeys("PlintronGlobal123");
		driver.findElementById("createLeadForm_firstName").sendKeys("senthilkumar");
		driver.findElementById("createLeadForm_lastName").sendKeys("sella muthu");
		//Source DropDown
		WebElement srcSource = driver.findElementById("createLeadForm_dataSourceId");
		Select sel = new Select(srcSource);
		sel.selectByIndex(3);
	
		//Marketing Campaign
		WebElement srcMarket = driver.findElementById("createLeadForm_marketingCampaignId");
		Select dropdown = new Select (srcMarket);
		dropdown.selectByValue("CATRQ_CARNDRIVER");
		
		driver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("09176619388");
		driver.findElementById("createLeadForm_primaryEmail").sendKeys("siva@gmail.com");
		//click the Create Lead button
		driver.findElementByClassName("smallSubmit").click();
		
		String leadID = driver.findElementById("viewLead_companyName_sp").getText();
		System.out.println("The Lead ID  "+leadID);
		
		}

}
