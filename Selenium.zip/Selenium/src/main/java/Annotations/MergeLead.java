package Annotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;


import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

public class MergeLead extends BaseUtils {
	
@Test (enabled = true)
	public void MergeLeadTest() throws InterruptedException {
		
		
		driver.findElementByLinkText("CRM/SFA").click();
		driver.findElementByXPath("//a[text()='Leads']").click();
		driver.findElementByXPath("//a[text()='Merge Leads']").click();
		
		//From Lead
		driver.findElementByXPath("//img[@alt='Lookup']").click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> lst = new ArrayList<>();
		lst.addAll(allWindows);
		driver.switchTo().window(lst.get(1));
		String childWindow = driver.getTitle();
		System.out.println(childWindow);
		driver.switchTo().window(lst.get(1));
		driver.findElementByXPath("//label[contains(text(),'Lead ID:')]/following::input").sendKeys("10088");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.switchTo().window(lst.get(0));
		driver.switchTo().defaultContent();
		
		//To Lead
		driver.findElementByXPath("(//img[@alt='Lookup'])[2]").click();
		Set<String> cAllWindows = driver.getWindowHandles();
		List<String> cLst = new ArrayList<>();
		cLst.addAll(cAllWindows);
		/*String titleBrowser = driver.getTitle();
		System.out.println(titleBrowser);*/
		driver.switchTo().window(cLst.get(1));
		String browTitle = driver.getTitle();
		System.out.println(browTitle);
		driver.findElementByXPath("(//label[contains(text(),'Lead ID:')]/following::input)[1]").sendKeys("10093");
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("(//div[@class='x-grid3-cell-inner x-grid3-col-partyId'])[1]/a").click();
		driver.switchTo().window(lst.get(0));
		
		driver.findElementByLinkText("Merge").click();
		
		driver.switchTo().alert().accept();
		
		driver.findElementByLinkText("Find Leads").click();
		
		driver.findElementByXPath("((//div[@class='x-form-element'])/input)[13]").sendKeys("10088");
		
		driver.findElementByXPath("(//button[@class='x-btn-text'])[7]").click();
		Thread.sleep(3000);
		 WebElement strText = driver.findElementByXPath("//div[@class='x-paging-info']");
		 String text = strText.getText();		 
		 System.out.println(text);
		 
		}
	
	
}
